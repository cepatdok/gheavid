<?php

namespace DynamicContentFormadxartwork;

use DynamicContentFormadxartwork\PageSettings\PageSettings_Scrollify;
use DynamicContentFormadxartwork\PageSettings\PageSettings_InertiaScroll;
use DynamicContentFormadxartwork\Helper;
use DynamicContentFormadxartwork\Core\Upgrade\Manager as UpgradeManager;
/**
 * Main Plugin Class
 *
 * @since 0.0.1
 */
class Plugin
{
    public static $backup_path = \WP_CONTENT_DIR . '/backup';
    private static $instance;
    /**
     * @var UpgradeManager
     */
    public $upgrade;
    /**
     * Constructor
     *
     * @since 0.0.1
     *
     * @access public
     */
    public function __construct()
    {
        $this->init();
    }
    public static function instance()
    {
        if (\is_null(self::$instance)) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    public function init()
    {
        // Instance classes
        $this->instances();
        add_action('admin_menu', [$this, 'add_dce_menu'], 200);
        // fire actions
        add_action('madxartwork/init', [$this, 'add_dce_to_madxartwork'], 0);
        add_filter('plugin_action_links_' . DCE_PLUGIN_BASE, [$this, 'plugin_action_links']);
        add_filter('plugin_row_meta', [$this, 'plugin_row_meta'], 10, 2);
        add_filter('pre_handle_404', [$this, 'dce_allow_posts_pagination'], 999, 2);
        add_action('madxartwork/element/form/section_form_fields/before_section_end', [$this, 'add_form_fields_enchanted_tab']);
    }
    public function instances()
    {
        $this->controls = new \DynamicContentFormadxartwork\Controls();
        $this->extensions = new \DynamicContentFormadxartwork\Extensions();
        $this->page_settings = new \DynamicContentFormadxartwork\PageSettings();
        $this->settings = new \DynamicContentFormadxartwork\Settings();
        // Dashboard
        $this->api = new \DynamicContentFormadxartwork\Dashboard\Api();
        $this->templatesystem = new \DynamicContentFormadxartwork\Dashboard\TemplateSystem();
        $this->license = new \DynamicContentFormadxartwork\Dashboard\License();
        $this->widgets = new \DynamicContentFormadxartwork\Widgets();
        $this->stripe = new \DynamicContentFormadxartwork\Stripe();
        $this->pdfHtmlTemplates = new \DynamicContentFormadxartwork\PdfHtmlTemplates();
        new \DynamicContentFormadxartwork\Ajax();
        new \DynamicContentFormadxartwork\Assets();
        new \DynamicContentFormadxartwork\Dashboard\Dashboard();
        new \DynamicContentFormadxartwork\LicenseSystem();
        new \DynamicContentFormadxartwork\TemplateSystem();
        new \DynamicContentFormadxartwork\Elements();
        // Init hook
        do_action('dynamic_content_for_madxartwork/init');
    }
    /**
     * Add Actions
     *
     * @since 0.0.1
     *
     * @access private
     */
    public function add_dce_to_madxartwork()
    {
        // Global Settings Panel
        \DynamicContentFormadxartwork\GlobalSettings::init();
        $this->upgrade = UpgradeManager::instance();
        // Controls
        add_action('madxartwork/controls/controls_registered', [$this->controls, 'on_controls_registered']);
        // Controls Manager
        \madxartwork\Plugin::$instance->controls_manager = new \DynamicContentFormadxartwork\DCE_Controls_Manager(\madxartwork\Plugin::$instance->controls_manager);
        // Extensions
        $this->extensions->on_extensions_registered();
        // Dynamic Tags
        $this->extensions->on_dynamic_tags_registered();
        // Page Settings
        $this->page_settings->on_page_settings_registered();
        // Widgets
        add_action('madxartwork/widgets/widgets_registered', [$this->widgets, 'on_widgets_registered']);
    }
    // This form tab is used for many extensions. We put it here avoiding
    // repetition at the small price of having the empty tab if the extensions
    // are disabled.
    public function add_form_fields_enchanted_tab($widget)
    {
        $madxartwork = \madxartworkPro\Plugin::madxartwork();
        $control_data = $madxartwork->controls_manager->get_control_from_stack($widget->get_unique_name(), 'form_fields');
        if (is_wp_error($control_data)) {
            return;
        }
        $field_controls = ['form_fields_enchanted_tab' => ['type' => 'tab', 'tab' => 'enchanted', 'label' => '<i class="dynicon icon-dyn-logo-dce" aria-hidden="true"></i>', 'tabs_wrapper' => 'form_fields_tabs', 'name' => 'form_fields_enchanted_tab', 'condition' => ['field_type!' => 'step']]];
        $control_data['fields'] = \array_merge($control_data['fields'], $field_controls);
        $widget->update_control('form_fields', $control_data);
    }
    public function add_dce_menu()
    {
        // Dynamic Content - Menu
        add_menu_page('Dynamic.ooo', 'Dynamic.ooo', 'manage_options', 'dce-features', [$this->settings, 'dce_setting_page'], 'data:image/svg+xml;base64,' . $this->dce_get_icon_svg(), '58.6');
        // Dynamic Content - Features
        add_submenu_page('dce-features', 'Dynamic.ooo - ' . __('Features', 'dynamic-content-for-madxartwork'), __('Features', 'dynamic-content-for-madxartwork'), 'manage_options', 'dce-features', [$this->settings, 'dce_setting_page']);
        add_submenu_page('dce-features', 'HTML Templates', 'HTML Templates', 'manage_options', 'edit.php?post_type=' . \DynamicContentFormadxartwork\PdfHtmlTemplates::CPT);
        // Dynamic Content - Template System
        add_submenu_page('dce-features', 'Dynamic.ooo - ' . __('Template System', 'dynamic-content-for-madxartwork'), __('Template System', 'dynamic-content-for-madxartwork'), 'manage_options', 'dce-templatesystem', [$this->templatesystem, 'display_form']);
        // Dynamic Content - APIs
        add_submenu_page('dce-features', 'Dynamic.ooo - ' . __('APIs', 'dynamic-content-for-madxartwork'), __('APIs', 'dynamic-content-for-madxartwork'), 'manage_options', 'dce-apis', [$this->api, 'display_form']);
        // Dynamic Content - License
        add_submenu_page('dce-features', 'Dynamic.ooo - ' . __('License', 'dynamic-content-for-madxartwork'), __('License', 'dynamic-content-for-madxartwork'), 'administrator', 'dce-license', [$this->license, 'show_license_form']);
    }
    public static function plugin_action_links($links)
    {
        $links['config'] = '<a title="Configuration" href="' . admin_url() . 'admin.php?page=dce-features">' . __('Configuration', 'dynamic-content-for-madxartwork') . '</a>';
        return $links;
    }
    public function plugin_row_meta($plugin_meta, $plugin_file)
    {
        if ('dynamic-content-for-madxartwork/dynamic-content-for-madxartwork.php' === $plugin_file) {
            $row_meta = ['docs' => '<a href="https://help.dynamic.ooo/" aria-label="' . esc_attr(__('View Documentation', 'dynamic-content-for-madxartwork')) . '" target="_blank">' . __('Docs', 'dynamic-content-for-madxartwork') . '</a>', 'community' => '<a href="http://facebook.com/groups/dynamic.ooo" aria-label="' . esc_attr(__('Facebook Community', 'dynamic-content-for-madxartwork')) . '" target="_blank">' . __('FB Community', 'dynamic-content-for-madxartwork') . '</a>'];
            $plugin_meta = \array_merge($plugin_meta, $row_meta);
        }
        return $plugin_meta;
    }
    public static function dce_get_icon_svg($base64 = \true)
    {
        $svg = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 88.74 71.31"><path d="M35.65,588.27h27.5c25.46,0,40.24,14.67,40.24,35.25v.2c0,20.58-15,35.86-40.65,35.86H35.65Zm27.81,53.78c11.81,0,19.65-6.51,19.65-18v-.2c0-11.42-7.84-18-19.65-18H55.41v36.26Z" transform="translate(-35.65 -588.27)" fill="#a8abad"/><path d="M121.69,609.94a33.84,33.84,0,0,0-7.56-11.19,36.51,36.51,0,0,0-11.53-7.56A37.53,37.53,0,0,0,88,588.4a43.24,43.24,0,0,0-5.4.34,36.53,36.53,0,0,1,20.76,10,33.84,33.84,0,0,1,7.56,11.19,35.25,35.25,0,0,1,2.7,13.79v.2a34.79,34.79,0,0,1-2.75,13.79,35.21,35.21,0,0,1-19.19,18.94,36.48,36.48,0,0,1-9.27,2.45,42.94,42.94,0,0,0,5.39.35,37.89,37.89,0,0,0,14.67-2.8,35.13,35.13,0,0,0,19.19-18.94,34.79,34.79,0,0,0,2.75-13.79v-.2A35.25,35.25,0,0,0,121.69,609.94Z" transform="translate(-35.65 -588.27)" fill="#a8abad" /></svg>';
        return \base64_encode($svg);
    }
    public function dce_allow_posts_pagination($preempt, $wp_query)
    {
        if ($preempt || empty($wp_query->query_vars['page']) || empty($wp_query->post) || !is_singular()) {
            return $preempt;
        }
        $allow_pagination = \false;
        $document = '';
        $current_post_id = $wp_query->post->ID;
        $dce_posts_widgets = ['dyncontel-acfposts', 'dce-dynamicposts-v2', 'dyncontel-dynamicusers', 'dce-sticky-posts', 'dce-my-posts', 'dce-dynamic-woo-products', 'dce-search-results', 'dce-show-favorites', 'dce-woo-products-cart', 'dce-woo-product-upsells', 'dce-woo-product-crosssells'];
        // Check if current post/page is built with madxartwork and check for DCE posts pagination
        if (\madxartwork\Plugin::$instance->db->is_built_with_madxartwork($current_post_id) && !$allow_pagination) {
            $allow_pagination = $this->dce_check_posts_pagination($current_post_id, $dce_posts_widgets);
        }
        $dce_template = get_option('dce_template');
        // Check if single DCE template is active and check for DCE posts pagination in template
        if (isset($dce_template) && 'active' == $dce_template && !$allow_pagination) {
            $options = get_option('dyncontel_options');
            $post_type = get_post_type($current_post_id);
            if ($options['dyncontel_field_single' . $post_type]) {
                $allow_pagination = $this->dce_check_posts_pagination($options['dyncontel_field_single' . $post_type], $dce_posts_widgets);
            }
        }
        // Check if single madxartwork Pro template is active and check for DCE posts pagination in template
        if (Helper::is_madxartworkpro_active() && !$allow_pagination) {
            $locations = \madxartworkPro\Modules\ThemeBuilder\Module::instance()->get_locations_manager()->get_locations();
            if (isset($locations['single'])) {
                $location_docs = \madxartworkPro\Modules\ThemeBuilder\Module::instance()->get_conditions_manager()->get_documents_for_location('single');
                if (!empty($location_docs)) {
                    foreach ($location_docs as $location_doc_id => $settings) {
                        if ($wp_query->post->ID !== $location_doc_id && !$allow_pagination) {
                            $allow_pagination = $this->dce_check_posts_pagination($location_doc_id, $dce_posts_widgets);
                            break;
                        }
                    }
                }
            }
        }
        if ($allow_pagination) {
            return $allow_pagination;
        } else {
            return $preempt;
        }
    }
    protected function dce_check_posts_pagination($post_id, $dce_posts_widgets, $current_page = null)
    {
        $pagination = \false;
        if ($post_id) {
            $document = \madxartwork\Plugin::$instance->documents->get($post_id);
            $document_elements = $document->get_elements_data();
            // Check if DCE posts widgets are present and if pagination or infinite scroll is active
            \madxartwork\Plugin::$instance->db->iterate_data($document_elements, function ($element) use(&$pagination, $dce_posts_widgets) {
                if (isset($element['widgetType']) && \in_array($element['widgetType'], $dce_posts_widgets, \true)) {
                    if (isset($element['settings']['pagination_enable'])) {
                        if ($element['settings']['pagination_enable']) {
                            $pagination = \true;
                        }
                    }
                    if (isset($element['settings']['infiniteScroll_enable'])) {
                        if ($element['settings']['infiniteScroll_enable']) {
                            $pagination = \true;
                        }
                    }
                }
            });
        }
        return $pagination;
    }
}
\DynamicContentFormadxartwork\Plugin::instance();
