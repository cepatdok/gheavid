<?php

namespace DynamicContentFormadxartwork;

trait Trait_Woo
{
    /**
     * Find matching product variation
     *
     * @param WC_Product $product
     * @param array $attributes
     * @return int Matching variation ID or 0.
     */
    public function find_matching_product_variation($product, $attributes)
    {
        foreach ($attributes as $key => $value) {
            if (\strpos($key, 'attribute_') === 0) {
                continue;
            }
            unset($attributes[$key]);
            $attributes[\sprintf('attribute_%s', $key)] = $value;
        }
        if (\class_exists('WC_Data_Store')) {
            $data_store = \WC_Data_Store::load('product');
            return $data_store->find_matching_product_variation($product, $attributes);
        } else {
            return $product->get_matching_variation($attributes);
        }
    }
    public function get_fields()
    {
        $fields = array();
        $fields['product'] = ['_price' => __('Price', 'dynamic-content-for-madxartwork'), '_sale_price' => __('Sale Price', 'dynamic-content-for-madxartwork'), '_regular_price' => __('Regular Price', 'dynamic-content-for-madxartwork'), '_average_rating' => __('Average Rating', 'dynamic-content-for-madxartwork'), '_stock_status' => __('Stock Status', 'dynamic-content-for-madxartwork'), '_on_sale' => __('On Sale', 'dynamic-content-for-madxartwork'), '_featured' => __('Featured', 'dynamic-content-for-madxartwork'), '_product_type' => __('Product Type', 'dynamic-content-for-madxartwork')];
        return $fields;
    }
}
