<?php

namespace DynamicContentFormadxartwork;

trait Trait_Notice
{
    public static function notice($title = '', $content = '')
    {
        ?>
	<div class="madxartwork-alert madxartwork-alert-info" role="alert">
		<?php 
        if ($title) {
            ?>
			<span class="madxartwork-alert-title"><?php 
            echo wp_kses_post($title);
            ?></span>
		<?php 
        }
        if ($content) {
            ?>
			<span class="madxartwork-alert-description"><?php 
            echo wp_kses_post($content);
            ?></span>
		<?php 
        }
        ?>
	</div>
	<?php 
    }
}
