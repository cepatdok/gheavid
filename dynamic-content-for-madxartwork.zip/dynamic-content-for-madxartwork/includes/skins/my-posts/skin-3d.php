<?php

namespace DynamicContentFormadxartwork\Includes\Skins;

if (!\defined('ABSPATH')) {
    exit;
    // Exit if accessed directly
}
class My_Posts_Skin_3D extends \DynamicContentFormadxartwork\Includes\Skins\Skin_3D
{
    protected function _register_controls_actions()
    {
        add_action('madxartwork/element/dce-my-posts/section_query/after_section_end', [$this, 'register_controls_layout']);
        add_action('madxartwork/element/dce-my-posts/section_dynamicposts/after_section_end', [$this, 'register_additional_3d_controls']);
    }
}
