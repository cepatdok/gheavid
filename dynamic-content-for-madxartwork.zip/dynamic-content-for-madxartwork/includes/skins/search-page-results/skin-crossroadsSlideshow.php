<?php

namespace DynamicContentFormadxartwork\Includes\Skins;

use DynamicContentFormadxartwork\Helper;
if (!\defined('ABSPATH')) {
    exit;
    // Exit if accessed directly
}
class Search_Page_Results_Skin_CrossroadsSlideshow extends \DynamicContentFormadxartwork\Includes\Skins\Skin_CrossroadsSlideshow
{
    protected function _register_controls_actions()
    {
        add_action('madxartwork/element/dce-search-results/section_query/after_section_end', [$this, 'register_controls_layout']);
        add_action('madxartwork/element/dce-search-results/section_dynamicposts/after_section_end', [$this, 'register_additional_crossroadsslideshow_controls']);
    }
}
