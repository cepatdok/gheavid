<?php

namespace DynamicContentFormadxartwork\Includes\Skins;

if (!\defined('ABSPATH')) {
    exit;
    // Exit if accessed directly
}
class Woo_Product_Upsells_Skin_DualCarousel extends \DynamicContentFormadxartwork\Includes\Skins\Skin_DualCarousel
{
    protected function _register_controls_actions()
    {
        add_action('madxartwork/element/dce-woo-product-upsells/section_query/after_section_end', [$this, 'register_controls_layout']);
        add_action('madxartwork/element/dce-woo-product-upsells/section_dynamicposts/after_section_end', [$this, 'register_additional_dualcarousel_controls']);
        add_action('madxartwork/element/dce-woo-product-upsells/section_dynamicposts/after_section_end', [$this, 'register_additional_carousel_controls']);
    }
}
