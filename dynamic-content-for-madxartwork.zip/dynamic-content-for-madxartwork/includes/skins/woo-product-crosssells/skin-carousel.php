<?php

namespace DynamicContentFormadxartwork\Includes\Skins;

if (!\defined('ABSPATH')) {
    exit;
    // Exit if accessed directly
}
class Woo_Product_Crosssells_Skin_Carousel extends \DynamicContentFormadxartwork\Includes\Skins\Skin_Carousel
{
    protected function _register_controls_actions()
    {
        add_action('madxartwork/element/dce-woo-product-crosssells/section_query/after_section_end', [$this, 'register_controls_layout']);
        add_action('madxartwork/element/dce-woo-product-crosssells/section_dynamicposts/after_section_end', [$this, 'register_additional_carousel_controls']);
    }
}
