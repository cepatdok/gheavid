<?php

namespace DynamicContentFormadxartwork\Widgets;

use madxartwork\Controls_Manager;
use madxartwork\Scheme_Color;
use madxartwork\Scheme_Typography;
use madxartwork\Group_Control_Typography;
use DynamicContentFormadxartwork\Helper;
// Exit if accessed directly
if (!\defined('ABSPATH')) {
    exit;
}
class DCE_Widget_TitleTaxonomy extends \DynamicContentFormadxartwork\Widgets\WidgetPrototype
{
    public function get_style_depends()
    {
        return ['dce-title'];
    }
    protected function _register_controls()
    {
        $post_type_object = get_post_type_object(get_post_type());
        $this->start_controls_section('section_titleTaxonomy', ['label' => __('Taxonomy Title', 'dynamic-content-for-madxartwork')]);
        $this->add_control('titleTaxonomy_text_before', ['label' => __('Text Before', 'dynamic-content-for-madxartwork'), 'type' => Controls_Manager::TEXT, 'default' => '']);
        $this->add_control('html_tag', ['label' => __('HTML Tag', 'dynamic-content-for-madxartwork'), 'type' => Controls_Manager::SELECT, 'options' => ['h1' => __('H1', 'dynamic-content-for-madxartwork'), 'h2' => __('H2', 'dynamic-content-for-madxartwork'), 'h3' => __('H3', 'dynamic-content-for-madxartwork'), 'h4' => __('H4', 'dynamic-content-for-madxartwork'), 'h5' => __('H5', 'dynamic-content-for-madxartwork'), 'h6' => __('H6', 'dynamic-content-for-madxartwork'), 'p' => __('p', 'dynamic-content-for-madxartwork'), 'div' => __('div', 'dynamic-content-for-madxartwork'), 'span' => __('span', 'dynamic-content-for-madxartwork')], 'default' => 'h2']);
        $this->add_responsive_control('align', ['label' => __('Alignment', 'dynamic-content-for-madxartwork'), 'type' => Controls_Manager::CHOOSE, 'options' => ['left' => ['title' => __('Left', 'dynamic-content-for-madxartwork'), 'icon' => 'fa fa-align-left'], 'center' => ['title' => __('Center', 'dynamic-content-for-madxartwork'), 'icon' => 'fa fa-align-center'], 'right' => ['title' => __('Right', 'dynamic-content-for-madxartwork'), 'icon' => 'fa fa-align-right'], 'justify' => ['title' => __('Justified', 'dynamic-content-for-madxartwork'), 'icon' => 'fa fa-align-justify']], 'default' => '', 'selectors' => ['{{WRAPPER}}' => 'text-align: {{VALUE}};']]);
        $this->add_control('link_to', ['label' => __('Link to', 'dynamic-content-for-madxartwork'), 'type' => Controls_Manager::SELECT, 'default' => 'none', 'options' => ['none' => __('None', 'dynamic-content-for-madxartwork'), 'home' => __('Home URL', 'dynamic-content-for-madxartwork'), 'archive' => 'Archive URL', 'custom' => __('Custom URL', 'dynamic-content-for-madxartwork')]]);
        $this->add_control('link', ['label' => __('Link', 'dynamic-content-for-madxartwork'), 'type' => Controls_Manager::URL, 'placeholder' => 'http://your-link.com', 'condition' => ['link_to' => 'custom'], 'default' => ['url' => ''], 'show_label' => \false]);
        $this->end_controls_section();
        $this->start_controls_section('section_style', ['label' => __('Title', 'dynamic-content-for-madxartwork'), 'tab' => Controls_Manager::TAB_STYLE]);
        $this->add_control('color', ['label' => __('Text Color', 'dynamic-content-for-madxartwork'), 'type' => Controls_Manager::COLOR, 'selectors' => ['{{WRAPPER}} .dynamic-content-for-madxartwork-title' => 'color: {{VALUE}};', '{{WRAPPER}} .dynamic-content-for-madxartwork-title a' => 'color: {{VALUE}};']]);
        $this->add_group_control(Group_Control_Typography::get_type(), ['name' => 'typography', 'selector' => '{{WRAPPER}} .dynamic-content-for-madxartwork-title']);
        $this->add_control('hover_animation', ['label' => __('Hover Animation', 'dynamic-content-for-madxartwork'), 'type' => Controls_Manager::HOVER_ANIMATION]);
        $this->end_controls_section();
    }
    protected function render()
    {
        $settings = $this->get_settings_for_display();
        if (empty($settings)) {
            return;
        }
        $id_title = '';
        $titolo = '';
        $title = '';
        if (is_single() || is_page()) {
            $titolo = wp_kses_post(get_the_title($id_title));
        } elseif (is_post_type_archive() || is_tax() || is_category() || is_tag() || is_author()) {
            // Archives
            $queried_object = get_queried_object();
            $tax = get_taxonomy($queried_object->taxonomy);
            $tax_labels = get_taxonomy_labels($tax);
            $titolo = $tax_labels->singular_name;
        } else {
            $titolo = wp_kses_post(get_the_title($id_title));
        }
        if ($settings['titleTaxonomy_text_before'] != '') {
            $title .= '<span>' . $settings['titleTaxonomy_text_before'] . '</span>';
        }
        $title .= $titolo;
        if (empty($title)) {
            return;
        }
        switch ($settings['link_to']) {
            case 'custom':
                if (!empty($settings['link']['url'])) {
                    $link = esc_url($settings['link']['url']);
                } else {
                    $link = \false;
                }
                break;
            case 'archive':
                $link = '';
                break;
            case 'home':
                $link = esc_url(get_home_url());
                break;
            case 'none':
            default:
                $link = \false;
                break;
        }
        $target = $settings['link']['is_external'] ? 'target="_blank"' : '';
        $animation_class = !empty($settings['hover_animation']) ? 'madxartwork-animation-' . $settings['hover_animation'] : '';
        $html = \sprintf('<%1$s class="dynamic-content-for-madxartwork-title %2$s">', \DynamicContentFormadxartwork\Helper::validate_html_tag($settings['html_tag']), $animation_class);
        if ($link) {
            $html .= \sprintf('<a href="%1$s" %2$s>%3$s</a>', $link, $target, $title);
        } else {
            $html .= $title;
        }
        $html .= \sprintf('</%s>', \DynamicContentFormadxartwork\Helper::validate_html_tag($settings['html_tag']));
        echo $html;
    }
}
