<?php

namespace DynamicContentFormadxartwork\Widgets;

use madxartwork\Controls_Manager;
use madxartwork\Repeater;
use madxartwork\Scheme_Color;
use madxartwork\Group_Control_Image_Size;
use madxartwork\Group_Control_Border;
use madxartwork\Group_Control_Box_Shadow;
use DynamicContentFormadxartwork\Helper;
if (!\defined('ABSPATH')) {
    exit;
    // Exit if accessed directly
}
class DCE_Widget_Tilt extends \DynamicContentFormadxartwork\Widgets\WidgetPrototype
{
    public function get_script_depends()
    {
        return ['tilt-lib', 'dce-tilt'];
    }
    protected function _register_controls()
    {
        $this->start_controls_section('section_tilt', ['label' => __('Tilt', 'dynamic-content-for-madxartwork')]);
        $this->add_control('template', ['label' => __('Select Template', 'dynamic-content-for-madxartwork'), 'type' => 'ooo_query', 'placeholder' => __('Template Name', 'dynamic-content-for-madxartwork'), 'label_block' => \true, 'query_type' => 'posts', 'object_type' => 'madxartwork_library']);
        $this->add_control('translatez_template', ['label' => __('Translate Z', 'dynamic-content-for-madxartwork'), 'type' => Controls_Manager::NUMBER, 'default' => 0, 'min' => 0, 'max' => 200, 'step' => 1, 'frontend_available' => \true, 'selectors' => ['{{WRAPPER}} .template-inner' => 'transform: translateZ({{VALUE}}px);']]);
        $this->add_control('tilt_maxtilt', ['label' => __('Max Tilt', 'dynamic-content-for-madxartwork'), 'type' => Controls_Manager::SLIDER, 'default' => ['size' => 5], 'range' => ['min' => 0, 'max' => 10, 'step' => 1], 'frontend_available' => \true]);
        $this->add_control('tilt_perspective', ['label' => __('Perspective', 'dynamic-content-for-madxartwork'), 'type' => Controls_Manager::NUMBER, 'default' => 1000, 'min' => 0, 'max' => 2000, 'step' => 10, 'frontend_available' => \true]);
        $this->add_control('tilt_scale', ['label' => __('Scale', 'dynamic-content-for-madxartwork'), 'type' => Controls_Manager::NUMBER, 'default' => 1, 'min' => 1, 'max' => 2, 'step' => 0.01]);
        $this->add_control('tilt_speed', ['label' => __('Speed', 'dynamic-content-for-madxartwork'), 'type' => Controls_Manager::NUMBER, 'default' => 300, 'min' => 0, 'max' => 1000, 'step' => 10, 'frontend_available' => \true]);
        $this->add_control('tilt_transition', ['label' => __('Transition', 'dynamic-content-for-madxartwork'), 'type' => Controls_Manager::SWITCHER, 'default' => 'yes', 'label_on' => __('Yes', 'dynamic-content-for-madxartwork'), 'label_off' => __('No', 'dynamic-content-for-madxartwork'), 'return_value' => 'yes', 'frontend_available' => \true]);
        $this->add_control('tilt_reset', ['label' => __('Reset', 'dynamic-content-for-madxartwork'), 'type' => Controls_Manager::SWITCHER, 'default' => 'yes', 'label_on' => __('Yes', 'dynamic-content-for-madxartwork'), 'label_off' => __('No', 'dynamic-content-for-madxartwork'), 'return_value' => 'yes', 'frontend_available' => \true]);
        $this->add_control('tilt_glare', ['label' => __('Glare', 'dynamic-content-for-madxartwork'), 'type' => Controls_Manager::SWITCHER, 'default' => '', 'label_on' => __('Yes', 'dynamic-content-for-madxartwork'), 'label_off' => __('No', 'dynamic-content-for-madxartwork'), 'return_value' => 'yes', 'frontend_available' => \true]);
        $this->add_control('tilt_maxGlare', ['label' => __('Max Glare', 'dynamic-content-for-madxartwork'), 'type' => Controls_Manager::NUMBER, 'default' => 1, 'min' => 0, 'max' => 1, 'step' => 0.1]);
        $this->end_controls_section();
    }
    protected function render()
    {
        $settings = $this->get_settings_for_display();
        $template = $settings['template'];
        echo '<div class="dce_tilt">';
        echo '<div class="js-tilt">';
        if ($template != '') {
            echo '<div class="template-inner">' . do_shortcode('[dce-madxartwork-template id="' . $template . '"]') . '</div>';
        } else {
            echo '<div class="tilt-inner"></div>';
        }
        echo '</div>';
        echo '</div>';
    }
}
