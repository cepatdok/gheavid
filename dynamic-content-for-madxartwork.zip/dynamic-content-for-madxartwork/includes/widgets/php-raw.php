<?php

namespace DynamicContentFormadxartwork\Widgets;

use madxartwork\Controls_Manager;
use DynamicContentFormadxartwork\Helper;
if (!\defined('ABSPATH')) {
    exit;
}
// Exit if accessed directly
class DCE_Widget_RawPhp extends \DynamicContentFormadxartwork\Widgets\WidgetPrototype
{
    public function show_in_panel()
    {
        if (!current_user_can('administrator')) {
            return \false;
        }
        return \true;
    }
    protected function _register_controls()
    {
        if (current_user_can('administrator') || !\madxartwork\Plugin::$instance->editor->is_edit_mode()) {
            $this->register_controls_content();
        } elseif (!current_user_can('administrator') && \madxartwork\Plugin::$instance->editor->is_edit_mode()) {
            $this->register_controls_non_admin_notice();
        }
    }
    protected function register_controls_content()
    {
        $this->start_controls_section('section_rawphp', ['label' => __('PHP Raw', 'dynamic-content-for-madxartwork')]);
        $this->add_control('custom_php', ['label' => __('PHP Code', 'dynamic-content-for-madxartwork'), 'type' => Controls_Manager::CODE, 'language' => 'php']);
        $this->end_controls_section();
    }
    protected function render()
    {
        $settings = $this->get_settings_for_display(null, \true);
        if (current_user_can('administrator') && \madxartwork\Plugin::$instance->editor->is_edit_mode() && empty($settings['custom_php'])) {
            Helper::notice('', __('Add your Custom PHP Code', 'dynamic-content-for-madxartwork'));
        } elseif (!current_user_can('administrator') && \madxartwork\Plugin::$instance->editor->is_edit_mode()) {
            $this->render_non_admin_notice();
        } elseif (current_user_can('administrator') && \madxartwork\Plugin::$instance->editor->is_edit_mode() && !empty($settings['custom_php']) || !is_admin() && !empty($settings['custom_php'])) {
            $evalError = \false;
            // The following is needed because if the code echoes only a
            // '0', madxartwork will not render the widget at all.
            echo '<!-- Dynamic PHP Raw -->';
            try {
                @eval($settings['custom_php']);
            } catch (\ParseError $e) {
                $evalError = \true;
            } catch (\Throwable $e) {
                $evalError = \true;
            }
            if ($evalError && \madxartwork\Plugin::$instance->editor->is_edit_mode()) {
                echo '<strong>';
                echo __('Please check your PHP code', 'dynamic-content-for-madxartwork');
                echo '</strong><br />';
                echo 'ERROR: ', $e->getMessage(), "\n";
            }
        }
    }
}
