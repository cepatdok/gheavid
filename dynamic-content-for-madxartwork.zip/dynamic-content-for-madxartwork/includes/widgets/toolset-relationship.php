<?php

namespace DynamicContentFormadxartwork\Widgets;

use madxartwork\Controls_Manager;
use madxartwork\Group_Control_Typography;
use madxartwork\Group_Control_Text_Shadow;
use madxartwork\Group_Control_Border;
use madxartwork\Group_Control_Box_Shadow;
use madxartwork\Group_Control_Background;
use DynamicContentFormadxartwork\Helper;
// Exit if accessed directly
if (!\defined('ABSPATH')) {
    exit;
}
class DCE_Widget_ToolsetRelationship extends \DynamicContentFormadxartwork\Widgets\WidgetPrototype
{
    public function get_style_depends()
    {
        return ['dce-relationship'];
    }
    public function show_in_panel()
    {
        if (!current_user_can('administrator')) {
            return \false;
        }
        return \true;
    }
    protected function _register_controls()
    {
        if (current_user_can('administrator') || !\madxartwork\Plugin::$instance->editor->is_edit_mode()) {
            $this->_register_controls_content();
        } elseif (!current_user_can('administrator') && \madxartwork\Plugin::$instance->editor->is_edit_mode()) {
            $this->register_controls_non_admin_notice();
        }
    }
    protected function _register_controls_content()
    {
        $rels = Helper::get_toolset_fields('post');
        $this->start_controls_section('section_content', ['label' => __('Content', 'dynamic-content-for-madxartwork')]);
        $this->add_control('toolset_relation_field', ['label' => __('TOOLSET Relation Fields List', 'dynamic-content-for-madxartwork'), 'type' => Controls_Manager::SELECT, 'groups' => $rels, 'default' => '0']);
        $this->add_control('toolset_relation_render', ['label' => __('Render mode', 'dynamic-content-for-madxartwork'), 'type' => Controls_Manager::CHOOSE, 'options' => ['title' => ['title' => __('Title', 'dynamic-content-for-madxartwork'), 'icon' => 'fa fa-list'], 'text' => ['title' => __('HTML & Tokens', 'dynamic-content-for-madxartwork'), 'icon' => 'fa fa-align-left'], 'template' => ['title' => __('Template', 'dynamic-content-for-madxartwork'), 'icon' => 'fa fa-th-large']], 'toggle' => \false, 'default' => 'title', 'separator' => 'before']);
        $this->add_control('toolset_relation_template', ['label' => __('Select Template', 'dynamic-content-for-madxartwork'), 'type' => 'ooo_query', 'placeholder' => __('Template Name', 'dynamic-content-for-madxartwork'), 'label_block' => \true, 'query_type' => 'posts', 'object_type' => 'madxartwork_library', 'condition' => ['toolset_relation_render' => 'template']]);
        $this->add_control('toolset_relation_text', ['label' => __('Post html', 'dynamic-content-for-madxartwork'), 'type' => Controls_Manager::WYSIWYG, 'default' => '<h4>[post:title]</h4>[post:thumb]<p>[post:excerpt]</p><a class="btn btn-primary" href="[post:permalink]">READ MORE</a>', 'description' => __('Define related post structure.', 'dynamic-content-for-madxartwork'), 'dynamic' => ['active' => \true], 'condition' => ['toolset_relation_render' => 'text']]);
        $this->add_control('toolset_relation_format', ['label' => __('Display mode', 'dynamic-content-for-madxartwork'), 'type' => Controls_Manager::SELECT, 'options' => ['' => __('Natural', 'dynamic-content-for-madxartwork'), 'ul' => __('Unordered list', 'dynamic-content-for-madxartwork'), 'ol' => __('Ordered list', 'dynamic-content-for-madxartwork'), 'grid' => __('Grid', 'dynamic-content-for-madxartwork'), 'tab' => __('Tabs', 'dynamic-content-for-madxartwork'), 'accordion' => __('Accordion', 'dynamic-content-for-madxartwork'), 'select' => __('Select', 'dynamic-content-for-madxartwork')]]);
        $this->add_control('toolset_relation_tag', ['label' => __('HTML Tag', 'dynamic-content-for-madxartwork'), 'type' => Controls_Manager::SELECT, 'options' => ['h1' => 'H1', 'h2' => 'H2', 'h3' => 'H3', 'h4' => 'H4', 'h5' => 'H5', 'h6' => 'H6', 'div' => 'div', 'span' => 'span', 'p' => 'p'], 'default' => 'h2']);
        $this->add_control('toolset_relation_link', ['label' => __('Link', 'dynamic-content-for-madxartwork'), 'type' => Controls_Manager::SWITCHER, 'condition' => ['toolset_relation_render' => 'title']]);
        $this->add_control('toolset_relation_label', ['label' => __('Label', 'dynamic-content-for-madxartwork'), 'type' => \madxartwork\Controls_Manager::TEXT, 'default' => '[post:title]', 'placeholder' => '[post:title]', 'condition' => ['toolset_relation_format' => ['tab', 'accordion', 'select']]]);
        $this->add_control('toolset_relation_close', ['label' => __('Close by default', 'dynamic-content-for-madxartwork'), 'type' => Controls_Manager::SWITCHER, 'condition' => ['toolset_relation_format' => ['accordion', 'select']]]);
        $this->add_control('toolset_relation_close_label', ['label' => __('Empty value text', 'dynamic-content-for-madxartwork'), 'type' => Controls_Manager::TEXT, 'default' => __('Choose an option', 'dynamic-content-for-madxartwork'), 'condition' => ['toolset_relation_close!' => '', 'toolset_relation_format' => 'select']]);
        $this->add_responsive_control('toolset_relation_col', ['label' => __('Columns', 'dynamic-content-for-madxartwork'), 'type' => \madxartwork\Controls_Manager::NUMBER, 'default' => 3, 'min' => 1, 'description' => __('Set 1 to show one result per line', 'dynamic-content-for-madxartwork'), 'condition' => ['toolset_relation_format' => 'grid']]);
        $this->add_control('toolset_relation_tab', ['label' => __('Tab orientation', 'dynamic-content-for-madxartwork'), 'type' => Controls_Manager::CHOOSE, 'options' => ['horizontal' => ['title' => __('Horizontal', 'dynamic-content-for-madxartwork'), 'icon' => 'fa fa-chevron-up'], 'vertical' => ['title' => __('Vertical', 'dynamic-content-for-madxartwork'), 'icon' => 'fa fa-chevron-left']], 'toggle' => \false, 'default' => 'horizontal', 'condition' => ['toolset_relation_format' => 'tab']]);
        $this->end_controls_section();
        $this->start_controls_section('section_style_title', ['label' => __('Title', 'dynamic-content-for-madxartwork'), 'tab' => Controls_Manager::TAB_STYLE]);
        $this->add_control('toolset_relation_title_padding', ['label' => __('Padding', 'dynamic-content-for-madxartwork'), 'type' => Controls_Manager::DIMENSIONS, 'selectors' => ['{{WRAPPER}} .madxartwork-heading-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};']]);
        $this->add_control('toolset_relation_title_margin', ['label' => __('Margin', 'dynamic-content-for-madxartwork'), 'type' => Controls_Manager::DIMENSIONS, 'selectors' => ['{{WRAPPER}} .madxartwork-heading-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};']]);
        $this->add_responsive_control('toolset_relation_title_align', ['label' => __('Alignment', 'dynamic-content-for-madxartwork'), 'type' => Controls_Manager::CHOOSE, 'options' => ['left' => ['title' => __('Left', 'dynamic-content-for-madxartwork'), 'icon' => 'fa fa-align-left'], 'center' => ['title' => __('Center', 'dynamic-content-for-madxartwork'), 'icon' => 'fa fa-align-center'], 'right' => ['title' => __('Right', 'dynamic-content-for-madxartwork'), 'icon' => 'fa fa-align-right'], 'justify' => ['title' => __('Justified', 'dynamic-content-for-madxartwork'), 'icon' => 'fa fa-align-justify']], 'default' => '', 'selectors' => ['{{WRAPPER}} .madxartwork-heading-title' => 'text-align: {{VALUE}};']]);
        $this->add_control('toolset_relation_title_color', ['label' => __('Text Color', 'dynamic-content-for-madxartwork'), 'type' => Controls_Manager::COLOR, 'selectors' => ['{{WRAPPER}} .madxartwork-heading-title' => 'color: {{VALUE}};']]);
        $this->add_group_control(Group_Control_Typography::get_type(), ['name' => 'toolset_relation_title_typography', 'selector' => '{{WRAPPER}} .madxartwork-heading-title']);
        $this->add_group_control(Group_Control_Text_Shadow::get_type(), ['name' => 'toolset_relation_title_text_shadow', 'selector' => '{{WRAPPER}} .madxartwork-heading-title']);
        $this->end_controls_section();
        $this->start_controls_section('section_style_atitle', ['label' => __('Title Active', 'dynamic-content-for-madxartwork'), 'tab' => Controls_Manager::TAB_STYLE, 'condition' => ['toolset_relation_format' => 'tab']]);
        $this->add_group_control(Group_Control_Background::get_type(), ['name' => 'toolset_relation_bgcolor_aitem', 'label' => __('Background', 'dynamic-content-for-madxartwork'), 'selector' => '{{WRAPPER}} .dce-tab-item.dce-tab-item-active']);
        $this->add_control('toolset_relation_color_aitem', ['label' => __('Text Color', 'dynamic-content-for-madxartwork'), 'type' => Controls_Manager::COLOR, 'selectors' => ['{{WRAPPER}} .dce-tab-item.dce-tab-item-active .madxartwork-heading-title' => 'color: {{VALUE}};']]);
        $this->end_controls_section();
        $this->start_controls_section('section_style_item', ['label' => __('Item', 'dynamic-content-for-madxartwork'), 'tab' => Controls_Manager::TAB_STYLE, 'condition' => ['toolset_relation_format' => ['accordion', 'tab']]]);
        $this->add_control('toolset_relation_padding_item', ['label' => __('Padding', 'dynamic-content-for-madxartwork'), 'type' => Controls_Manager::DIMENSIONS, 'selectors' => ['{{WRAPPER}} .dce-view-item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};']]);
        $this->add_group_control(Group_Control_Border::get_type(), ['name' => 'toolset_relation_border_item', 'label' => __('Border', 'dynamic-content-for-madxartwork'), 'selector' => '{{WRAPPER}} .dce-view-item']);
        $this->add_control('toolset_relation_border_radius_item', ['label' => __('Border Radius', 'dynamic-content-for-madxartwork'), 'type' => Controls_Manager::DIMENSIONS, 'selectors' => ['{{WRAPPER}} .dce-view-item' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};']]);
        $this->add_group_control(Group_Control_Background::get_type(), ['name' => 'toolset_relation_bgcolor_item', 'label' => __('Background', 'dynamic-content-for-madxartwork'), 'selector' => '{{WRAPPER}} .dce-view-item']);
        $this->end_controls_section();
        $this->start_controls_section('section_style_pane', ['label' => __('Pane', 'dynamic-content-for-madxartwork'), 'tab' => Controls_Manager::TAB_STYLE, 'condition' => ['toolset_relation_format' => ['accordion', 'tab', 'grid', 'select', 'ul', 'ol']]]);
        $this->add_control('toolset_relation_padding_pane', ['label' => __('Padding', 'dynamic-content-for-madxartwork'), 'type' => Controls_Manager::DIMENSIONS, 'selectors' => ['{{WRAPPER}} .dce-view-pane' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};']]);
        $this->add_control('toolset_relation_margin_pane', ['label' => __('Margin', 'dynamic-content-for-madxartwork'), 'type' => Controls_Manager::DIMENSIONS, 'selectors' => ['{{WRAPPER}} .dce-view-pane' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};']]);
        $this->add_group_control(Group_Control_Border::get_type(), ['name' => 'toolset_relation_border_pane', 'label' => __('Border', 'dynamic-content-for-madxartwork'), 'selector' => '{{WRAPPER}} .dce-view-pane']);
        $this->add_control('toolset_relation_border_radius_pane', ['label' => __('Border Radius', 'dynamic-content-for-madxartwork'), 'type' => Controls_Manager::DIMENSIONS, 'selectors' => ['{{WRAPPER}} .dce-view-pane' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};']]);
        $this->add_control('toolset_relation_color_pane', ['label' => __('Text Color', 'dynamic-content-for-madxartwork'), 'type' => Controls_Manager::COLOR, 'selectors' => ['{{WRAPPER}} .dce-view-pane' => 'color: {{VALUE}};']]);
        $this->add_group_control(Group_Control_Background::get_type(), ['name' => 'toolset_relation_bgcolor_pane', 'label' => __('Background', 'dynamic-content-for-madxartwork'), 'selector' => '{{WRAPPER}} .dce-view-pane']);
        $this->end_controls_section();
    }
    protected function render()
    {
        $settings = $this->get_settings_for_display(null, \true);
        if (empty($settings)) {
            return;
        }
        global $post;
        $old_post = $post;
        if ($settings['toolset_relation_field']) {
            $pezzi = \explode('-', $settings['toolset_relation_field'], 2);
            $field = \end($pezzi);
            $rel_posts = types_render_field($field, array('post_id' => $post->ID));
            if (\is_numeric($rel_posts)) {
                $rel_post = array($rel_posts);
            } elseif (isset($rel_posts['ID'])) {
                $rel_post = array($rel_posts['ID']);
            } elseif (\is_array($rel_posts)) {
                $rel_post = wp_list_pluck($rel_posts, 'ID');
            }
            if ($rel_post) {
                if (\is_array($rel_post) && !empty($rel_post)) {
                    if (\count($rel_post) > 1 && $settings['toolset_relation_format']) {
                        $labels = array();
                        if (\in_array($settings['toolset_relation_format'], array('tab', 'accordion', 'select'))) {
                            foreach ($rel_post as $arel) {
                                $post = get_post($arel);
                                $labels[$post->ID] = \DynamicContentFormadxartwork\Tokens::do_tokens($settings['toolset_relation_label']);
                            }
                        }
                        switch ($settings['toolset_relation_format']) {
                            case 'ul':
                                echo '<ul class="dce-toolset-relational-list">';
                                break;
                            case 'ol':
                                echo '<ol class="dce-toolset-relational-list">';
                                break;
                            case 'grid':
                                echo '<div class="dce-view-row grid-page grid-col-md-' . $settings['toolset_relation_col'] . ' grid-col-sm-' . $settings['toolset_relation_col_tablet'] . ' grid-col-xs-' . $settings['toolset_relation_col_mobile'] . '">';
                                break;
                            case 'tab':
                                echo '<div class="dce-view-tab dce-tab dce-tab-' . $settings['toolset_relation_tab'] . '"><ul>';
                                $i = 0;
                                foreach ($labels as $pkey => $alabel) {
                                    ?>
									<li>
										<a class="dce-view-item dce-tab-item<?php 
                                    echo !$i ? ' dce-tab-item-active' : '';
                                    ?>" href="#dce-toolset-relational-post-<?php 
                                    echo $this->get_id() . '-' . $pkey;
                                    ?>" onclick="jQuery('.madxartwork-element-<?php 
                                    echo $this->get_id();
                                    ?> .dce-toolset-relational-post').hide();jQuery('.madxartwork-element-<?php 
                                    echo $this->get_id();
                                    ?> .dce-tab-item-active').removeClass('dce-tab-item-active');jQuery(jQuery(this).attr('href')).show();jQuery(this).addClass('dce-tab-item-active'); return false;">
											<<?php 
                                    echo \DynamicContentFormadxartwork\Helper::validate_html_tag($settings['toolset_relation_tag']);
                                    ?> class="madxartwork-heading-title">
									<?php 
                                    echo $alabel;
                                    ?>
											</<?php 
                                    echo \DynamicContentFormadxartwork\Helper::validate_html_tag($settings['toolset_relation_tag']);
                                    ?>>
										</a>
									</li>
									<?php 
                                    $i++;
                                }
                                echo '</ul><div class="dce-tab-content">';
                                break;
                            case 'select':
                                ?>
								<select class="madxartwork-heading-title dce-view-select" onchange="jQuery('.madxartwork-element-<?php 
                                echo $this->get_id();
                                ?> .dce-toolset-relational-post').slideUp();jQuery(jQuery(this).val()).slideDown();">
									<?php 
                                if ($settings['toolset_relation_close'] && $settings['toolset_relation_close_label']) {
                                    echo '<option value="#dce-view-no-show">' . $settings['toolset_relation_close_label'] . '</option>';
                                }
                                foreach ($labels as $pkey => $alabel) {
                                    echo '<option value="#dce-toolset-relational-post-' . $this->get_id() . '-' . $pkey . '">' . $alabel . '</option>';
                                }
                                ?>
								</select>
								<div class="dce-select-content">
									<?php 
                                break;
                        }
                    }
                    foreach ($rel_post as $rkey => $arel) {
                        $post = get_post($arel);
                        if (\count($rel_post) > 1) {
                            switch ($settings['toolset_relation_format']) {
                                case 'ul':
                                case 'ol':
                                    echo '<li class="dce-view-pane dce-toolset-relational-post dce-toolset-relational-post-' . $post->ID . '">';
                                    break;
                                default:
                                    if ($settings['toolset_relation_format'] == 'accordion' && $settings['toolset_relation_render'] != 'title') {
                                        ?>
											<div class="dce-accordion-item">
												<a class="dce-view-item" href="#dce-toolset-relational-post-<?php 
                                        echo $this->get_id() . '-' . $post->ID;
                                        ?>" onclick="if (!jQuery(jQuery(this).attr('href')).is(':visible')) {
																								jQuery('.madxartwork-element-<?php 
                                        echo $this->get_id();
                                        ?> .dce-toolset-relational-post').slideUp();
																								jQuery(jQuery(this).attr('href')).slideDown();
																							} else {
																								jQuery(jQuery(this).attr('href')).slideUp();
																							} return false;">
													<<?php 
                                        echo \DynamicContentFormadxartwork\Helper::validate_html_tag($settings['toolset_relation_tag']);
                                        ?> class="madxartwork-heading-title">
												<?php 
                                        echo $labels[$post->ID];
                                        ?>
													</<?php 
                                        echo \DynamicContentFormadxartwork\Helper::validate_html_tag($settings['toolset_relation_tag']);
                                        ?>>
												</a>
											</div>
										<?php 
                                    }
                                    $is_hidden = \false;
                                    if (\in_array($settings['toolset_relation_format'], array('accordion', 'select'))) {
                                        if ($settings['toolset_relation_close'] && !$rkey || $rkey) {
                                            $is_hidden = \true;
                                        }
                                    }
                                    if (\in_array($settings['toolset_relation_format'], array('tab')) && $rkey) {
                                        $is_hidden = \true;
                                    }
                                    $pstyle = $is_hidden ? ' style="display: none;"' : '';
                                    echo '<div id="dce-toolset-relational-post-' . $this->get_id() . '-' . $post->ID . '" class="dce-view-pane dce-' . $settings['toolset_relation_format'] . '-pane dce-toolset-relational-post dce-toolset-relational-post-' . $post->ID . ($settings['toolset_relation_format'] == 'grid' ? ' item-page' : '') . '"' . $pstyle . '>';
                                    break;
                            }
                        }
                        if ($settings['toolset_relation_render'] == 'template' && $settings['toolset_relation_template']) {
                            echo do_shortcode('[dce-madxartwork-template id="' . $settings['toolset_relation_template'] . '"]');
                        } elseif ($settings['toolset_relation_render'] == 'text') {
                            echo \DynamicContentFormadxartwork\Tokens::do_tokens($settings['toolset_relation_text']);
                        } else {
                            if ($settings['toolset_relation_link']) {
                                echo '<a class="dce-toolset-relational-post-link" href="' . get_permalink($post->ID) . '">';
                            }
                            echo '<' . \DynamicContentFormadxartwork\Helper::validate_html_tag($settings['toolset_relation_tag']) . ' class="madxartwork-heading-title">' . wp_kses_post(get_the_title($post->ID)) . '</' . \DynamicContentFormadxartwork\Helper::validate_html_tag($settings['toolset_relation_tag']) . '>';
                            if ($settings['toolset_relation_link']) {
                                echo '</a>';
                            }
                        }
                        if (\count($rel_post) > 1) {
                            switch ($settings['toolset_relation_format']) {
                                case 'ul':
                                case 'ol':
                                    echo '</li>';
                                    break;
                                default:
                                    echo '</div>';
                                    break;
                            }
                        }
                    }
                    if (\count($rel_post) > 1 && $settings['toolset_relation_format']) {
                        switch ($settings['toolset_relation_format']) {
                            case 'ul':
                                echo '</ul>';
                                break;
                            case 'ol':
                                echo '</ol>';
                                break;
                            case 'tab':
                                echo '</div>';
                                break;
                            case 'grid':
                            case 'select':
                                echo '</div>';
                                break;
                        }
                    }
                }
            }
        }
        wp_reset_postdata();
        $post = $old_post;
        setup_postdata($old_post);
    }
}
