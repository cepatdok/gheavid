<?php

namespace DynamicContentFormadxartwork\Extensions;

use madxartwork\Group_Control_Border;
use madxartwork\Core\Kits\Documents\Tabs\Global_Colors;
use madxartwork\Controls_Manager;
use madxartwork\Controls_Stack;
use DynamicContentFormadxartwork\Helper;
use madxartworkPro\Modules\Forms\Fields;
use madxartworkPro\Modules\Forms\Classes;
use madxartworkPro\Modules\Forms\Widgets\Form;
use madxartworkPro\Plugin;
if (!\defined('ABSPATH')) {
    exit;
    // Exit if accessed directly
}
class HiddenLabel extends \madxartworkPro\Modules\Forms\Fields\Field_Base
{
    public $has_action = \false;
    public $depended_scripts = ['dce-hidden-label'];
    public $depended_styles = ['dce-hidden-label'];
    public function get_type()
    {
        return 'hidden_label';
    }
    public function get_name()
    {
        return 'Hidden Label';
    }
    public function get_script_depends()
    {
        return $this->depended_scripts;
    }
    public function get_style_depends()
    {
        return $this->depended_styles;
    }
    public function update_controls($widget)
    {
        $madxartwork = Plugin::madxartwork();
        $control_data = $madxartwork->controls_manager->get_control_from_stack($widget->get_unique_name(), 'form_fields');
        if (is_wp_error($control_data)) {
            return;
        }
        $field_controls = ['dce_hidden_label_id' => ['name' => 'dce_hidden_label_id', 'label' => __('Field ID', 'dynamic-content-for-madxartwork'), 'description' => __('The ID of the field we should get the selected choice label from. ', 'dynamic-content-for-madxartwork'), 'label_block' => \true, 'type' => \madxartwork\Controls_Manager::TEXT, 'tab' => 'content', 'inner_tab' => 'form_fields_content_tab', 'tabs_wrapper' => 'form_fields_tabs', 'dynamic' => ['active' => \false], 'condition' => ['field_type' => $this->get_type()]]];
        $control_data['fields'] = $this->inject_field_controls($control_data['fields'], $field_controls);
        $widget->update_control('form_fields', $control_data);
    }
    public function render($item, $item_index, $form)
    {
        $form->add_render_attribute('input' . $item_index, 'type', 'hidden', \true);
        $form->add_render_attribute('input' . $item_index, 'size', '1', \true);
        $form->add_render_attribute('input' . $item_index, 'data-field-id', $item['dce_hidden_label_id'], \true);
        echo '<input ' . $form->get_render_attribute_string('input' . $item_index) . '>';
    }
}
