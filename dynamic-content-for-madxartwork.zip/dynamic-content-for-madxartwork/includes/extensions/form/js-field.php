<?php

namespace DynamicContentFormadxartwork\Extensions;

use madxartwork\Core\Kits\Documents\Tabs\Global_Colors;
use madxartwork\Controls_Manager;
use madxartwork\Controls_Stack;
use DynamicContentFormadxartwork\Helper;
use DynamicContentFormadxartwork\Tokens;
use madxartwork\Group_Control_Border;
use madxartwork\Group_Control_Typography;
use madxartwork\Group_Control_Text_Shadow;
use madxartwork\Group_Control_Background;
use madxartwork\Group_Control_Box_Shadow;
use madxartworkPro\Modules\Forms\Fields;
use madxartwork\Widget_Base;
use madxartworkPro\Modules\Forms\Classes;
use madxartworkPro\Modules\Forms\Widgets\Form;
use madxartworkPro\Plugin;
if (!\defined('ABSPATH')) {
    exit;
    // Exit if accessed directly
}
class JsField extends \madxartworkPro\Modules\Forms\Fields\Field_Base
{
    public $depended_scripts = ['dce-js-field'];
    public function __construct()
    {
        add_action('madxartwork/widget/print_template', function ($template, $widget) {
            if ('form' === $widget->get_name()) {
                $template = \false;
            }
            return $template;
        }, 10, 2);
        parent::__construct();
    }
    public function get_script_depends()
    {
        return $this->depended_scripts;
    }
    public function get_name()
    {
        return 'JS Field';
    }
    public function get_label()
    {
        return __('JS Field', 'dynamic-content-for-madxartwork');
    }
    public function get_type()
    {
        return 'dce_js_field';
    }
    public function get_style_depends()
    {
        return $this->depended_styles;
    }
    public function update_controls($widget)
    {
        if (!current_user_can('administrator') && \madxartwork\Plugin::$instance->editor->is_edit_mode()) {
            return;
        }
        $madxartwork = Plugin::madxartwork();
        $control_data = $madxartwork->controls_manager->get_control_from_stack($widget->get_unique_name(), 'form_fields');
        if (is_wp_error($control_data)) {
            return;
        }
        $field_controls = ['dce_js_field_code' => ['name' => 'dce_js_field_code', 'label' => __('JS Code', 'dynamic-content-for-madxartwork'), 'description' => __('Your code should return a function. This function will be called whenever a form input changes. It should return a new value for this field. Use the function <code>getField(fieldId)</code> to get a field current value. Notice that all fields are returned as either strings or arrays of strings.', 'dynamic-content-for-madxartwork'), 'type' => \madxartwork\Controls_Manager::CODE, 'default' => 'return () => { return "Hello " + getField("name"); };', 'language' => 'javascript', 'label_block' => 'true', 'tab' => 'content', 'inner_tab' => 'form_fields_content_tab', 'tabs_wrapper' => 'form_fields_tabs', 'condition' => ['field_type' => $this->get_type()]], 'dce_js_field_hide' => ['name' => 'dce_js_field_hide', 'label' => __('Hide', 'dynamic-content-for-madxartwork'), 'type' => Controls_Manager::SWITCHER, 'description' => __('Do not display the field in the form, use its value only in the Actions (like Email)', 'dynamic-content-for-madxartwork'), 'tab' => 'content', 'inner_tab' => 'form_fields_content_tab', 'tabs_wrapper' => 'form_fields_tabs', 'condition' => ['field_type' => $this->get_type()]], 'dce_js_field_real_time' => ['name' => 'dce_js_field_real_time', 'label' => __('Update on each Keypress', 'dynamic-content-for-madxartwork'), 'type' => Controls_Manager::SWITCHER, 'description' => __('Do not wait for the field to be blurred for the event to be triggered. Do it on each keypress.', 'dynamic-content-for-madxartwork'), 'tab' => 'content', 'inner_tab' => 'form_fields_content_tab', 'tabs_wrapper' => 'form_fields_tabs', 'condition' => ['field_type' => $this->get_type()]]];
        $control_data['fields'] = $this->inject_field_controls($control_data['fields'], $field_controls);
        $widget->update_control('form_fields', $control_data);
    }
    /**
     * @param      $item
     * @param      $item_index
     * @param Form $form
     */
    public function render($item, $item_index, $form)
    {
        $method = $form->get_settings('form_method');
        if ($method === 'post' || $method === 'get') {
            echo '<p><span class="madxartwork-message madxartwork-message-danger madxartwork-help-inline madxartwork-form-help-inline" role="alert">';
            echo __('JS Field is not compatible with the Method Extension Post and Get options.', 'dynamic-content-for-madxartwork');
            echo '</span></p>';
            return;
        }
        $code = $item['dce_js_field_code'];
        $full_code = <<<EOD
jQuery(window).on('dce/jsfield-loaded', () => {
\tdceJsField.registerRefresherGenerator("{$item['custom_id']}", (getField) => {
\t\t{$code}
\t})
});
EOD;
        wp_add_inline_script('dce-js-field', $full_code, 'before');
        wp_localize_script('dce-js-field', 'jsFieldLocale', ['syntaxError' => __('Your JS Field code contains errors, check the browser console!', 'dynamic-content-for-madxartwork'), 'returnError' => __('Your JS Field code should return a function.', 'dynamic-content-for-madxartwork')]);
        if ($item['dce_js_field_hide'] === 'yes') {
            $form->add_render_attribute('input' . $item_index, 'data-hide', 'yes');
        }
        $form->add_render_attribute('input' . $item_index, 'data-field-id', $item['custom_id']);
        $form->add_render_attribute('input' . $item_index, 'data-real-time', $item['dce_js_field_real_time'] ?? 'no');
        $form->add_render_attribute('input' . $item_index, 'class', 'madxartwork-field-textual');
        $form->add_render_attribute('input' . $item_index, 'type', 'text');
        $form->add_render_attribute('input' . $item_index, 'readonly', '');
        echo '<input size="1"' . $form->get_render_attribute_string('input' . $item_index) . '>';
    }
}
