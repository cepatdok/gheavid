<?php

namespace DynamicContentFormadxartwork\Extensions;

use madxartwork\Controls_Manager;
use madxartwork\Controls_Stack;
use madxartwork\Group_Control_Typography;
use madxartwork\Group_Control_Border;
use madxartwork\Icons_Manager;
use DynamicContentFormadxartwork\Helper;
if (!\defined('ABSPATH')) {
    exit;
    // Exit if accessed directly
}
class DCE_Extension_Form_Password_Visibility extends \DynamicContentFormadxartwork\Extensions\DCE_Extension_Prototype
{
    private $is_common = \false;
    public $has_action = \false;
    /**
     * Get Name
     *
     * Return the action name
     *
     * @access public
     * @return string
     */
    public function get_name()
    {
        return 'dce_form_password_visibility';
    }
    /**
     * Get Label
     *
     * Returns the action label
     *
     * @access public
     * @return string
     */
    public function get_label()
    {
        return __('Password Visibility', 'dynamic-content-for-madxartwork');
    }
    /**
     * Add Actions
     *
     * @since 0.5.5
     *
     * @access private
     */
    protected function add_actions()
    {
        add_action('madxartwork/widget/render_content', array($this, '_render_form'), 10, 2);
        add_action('madxartwork/widget/print_template', function ($template, $widget) {
            if ('form' === $widget->get_name()) {
                $template = \false;
            }
            return $template;
        }, 10, 2);
    }
    public function _render_form($content, $widget)
    {
        if ($widget->get_name() == 'form') {
            $settings = $widget->get_settings_for_display();
            $jkey = 'dce_' . $widget->get_type() . '_form_' . $widget->get_id() . '_psw';
            \ob_start();
            ?>
			<script id="<?php 
            echo $jkey;
            ?>">
				(function ($) {
			<?php 
            if (!\madxartwork\Plugin::$instance->editor->is_edit_mode()) {
                ?>
					var <?php 
                echo $jkey;
                ?> = function ($scope, $) {
						if ($scope.hasClass("madxartwork-element-<?php 
                echo $widget->get_id();
                ?>")) {
				<?php 
            }
            $has_psw = \false;
            foreach ($settings['form_fields'] as $key => $afield) {
                if ($afield['field_type'] == 'password') {
                    if (!empty($afield['field_psw_visiblity'])) {
                        $has_psw = \true;
                        ?>
						jQuery('.madxartwork-element-<?php 
                        echo $widget->get_id();
                        ?> #form-field-<?php 
                        echo $afield['custom_id'];
                        ?>').addClass('dce-form-password-toggle');
						<?php 
                    }
                }
            }
            if ($has_psw) {
                wp_enqueue_style('font-awesome');
                ?>
				jQuery('.madxartwork-element-<?php 
                echo $widget->get_id();
                ?> .dce-form-password-toggle').each(function () {
					jQuery(this).wrap('<div class="dce-field-input-wrapper dce-field-input-wrapper-<?php 
                echo $afield['custom_id'];
                ?>"></div>');
					jQuery(this).parent().append('<span class="fa far fa-eye-slash field-icon dce-toggle-password"></span>');
					jQuery(this).next('.dce-toggle-password').on('click', function () {
						var input_psw = jQuery(this).prev();
						if (input_psw.attr('type') == 'password') {
							input_psw.attr('type', 'text');
						} else {
							input_psw.attr('type', 'password');
						}
						jQuery(this).toggleClass('fa-eye').toggleClass('fa-eye-slash');
					});
				});
				<?php 
            }
            if (!\madxartwork\Plugin::$instance->editor->is_edit_mode()) {
                ?>
							}
						};
						$(window).on("madxartwork/frontend/init", function () {
							madxartworkFrontend.hooks.addAction("frontend/element_ready/form.default", <?php 
                echo $jkey;
                ?>);
						});
			<?php 
            }
            ?>
				})(jQuery, window);
			</script>
			<?php 
            $add_js = \ob_get_clean();
            if ($has_psw) {
                $add_js = \DynamicContentFormadxartwork\Assets::dce_enqueue_script($jkey, $add_js);
                return $content . $add_js;
            }
        }
        return $content;
    }
    public static function _add_to_form(Controls_Stack $element, $control_id, $control_data, $options = [])
    {
        if ($element->get_name() == 'form' && $control_id == 'form_fields') {
            $control_data['fields']['form_fields_enchanted_tab'] = array('type' => 'tab', 'tab' => 'enchanted', 'label' => '<i class="dynicon icon-dyn-logo-dce" aria-hidden="true"></i>', 'tabs_wrapper' => 'form_fields_tabs', 'name' => 'form_fields_enchanted_tab', 'condition' => ['field_type!' => 'step']);
            $control_data['fields']['field_psw_visiblity'] = array('name' => 'field_psw_visiblity', 'label' => __('Password Visibility', 'dynamic-content-for-madxartwork'), 'type' => Controls_Manager::SWITCHER, 'return_value' => 'true', 'separator' => 'before', 'default' => 'true', 'conditions' => ['terms' => [['name' => 'field_type', 'value' => 'password']]], 'tabs_wrapper' => 'form_fields_tabs', 'inner_tab' => 'form_fields_enchanted_tab', 'tab' => 'enchanted');
        }
        return $control_data;
    }
}
