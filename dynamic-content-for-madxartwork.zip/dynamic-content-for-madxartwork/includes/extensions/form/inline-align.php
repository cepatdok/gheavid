<?php

namespace DynamicContentFormadxartwork\Extensions;

use madxartwork\Controls_Manager;
use madxartwork\Controls_Stack;
use madxartwork\Group_Control_Typography;
use madxartwork\Group_Control_Border;
use madxartwork\Icons_Manager;
use DynamicContentFormadxartwork\Helper;
if (!\defined('ABSPATH')) {
    exit;
    // Exit if accessed directly
}
class DCE_Extension_Form_Inline_Align extends \DynamicContentFormadxartwork\Extensions\DCE_Extension_Prototype
{
    private $is_common = \false;
    public $has_action = \false;
    /**
     * Get Name
     *
     * Return the action name
     *
     * @access public
     * @return string
     */
    public function get_name()
    {
        return 'dce_form_inline_align';
    }
    /**
     * Get Label
     *
     * Returns the action label
     *
     * @access public
     * @return string
     */
    public function get_label()
    {
        return __('Inline align', 'dynamic-content-for-madxartwork');
    }
    /**
     * Add Actions
     *
     * @since 0.5.5
     *
     * @access private
     */
    protected function add_actions()
    {
        add_action('madxartwork/widget/render_content', array($this, '_render_form'), 10, 2);
        add_action('madxartwork/widget/print_template', function ($template, $widget) {
            if ('form' === $widget->get_name()) {
                $template = \false;
            }
            return $template;
        }, 10, 2);
    }
    public function _render_form($content, $widget)
    {
        if ($widget->get_name() == 'form') {
            $settings = $widget->get_settings_for_display();
            $add_css = $add_js = '';
            $has_js = \false;
            foreach ($settings['form_fields'] as $key => $afield) {
                if ($afield['field_type'] == 'radio' || $afield['field_type'] == 'checkbox') {
                    if (!empty($afield['inline_align'])) {
                        $has_js = \true;
                        $add_js .= "jQuery('.madxartwork-field-group-" . $afield['custom_id'] . "').addClass('madxartwork-repeater-item-" . $afield['_id'] . "');";
                        $add_css .= '.madxartwork-field-group-' . $afield['custom_id'] . '.madxartwork-repeater-item-' . $afield['_id'] . ' .madxartwork-subgroup-inline{width: 100%; justify-content: ' . $afield['inline_align'] . ';}';
                    }
                }
            }
            if ($has_js) {
                $add_js = '<script>jQuery(function(){' . $add_js . '});</script>';
                $add_css = '<style>' . $add_css . '</style>';
                $add_js = \DynamicContentFormadxartwork\Assets::dce_enqueue_script($this->get_name() . '-' . $widget->get_id() . '-inline', $add_js);
                $add_css = \DynamicContentFormadxartwork\Assets::dce_enqueue_style($this->get_name() . '-' . $widget->get_id() . '-inline', $add_css);
                return $content . $add_js . $add_css;
            }
        }
        return $content;
    }
    public static function _add_to_form(Controls_Stack $element, $control_id, $control_data, $options = [])
    {
        if ($element->get_name() == 'form' && $control_id == 'form_fields') {
            $control_data['fields']['form_fields_enchanted_tab'] = array('type' => 'tab', 'tab' => 'enchanted', 'label' => '<i class="dynicon icon-dyn-logo-dce" aria-hidden="true"></i>', 'tabs_wrapper' => 'form_fields_tabs', 'name' => 'form_fields_enchanted_tab', 'condition' => ['field_type!' => 'step']);
            $control_data['fields']['inline_align'] = array('name' => 'inline_align', 'label' => __('Inline align', 'dynamic-content-for-madxartwork'), 'type' => Controls_Manager::CHOOSE, 'separator' => 'before', 'options' => ['flex-start' => ['title' => __('Left', 'dynamic-content-for-madxartwork'), 'icon' => 'eicon-text-align-left'], 'center' => ['title' => __('Center', 'dynamic-content-for-madxartwork'), 'icon' => 'eicon-text-align-center'], 'flex-end' => ['title' => __('Right', 'dynamic-content-for-madxartwork'), 'icon' => 'eicon-text-align-right'], 'space-around' => ['title' => __('Around', 'dynamic-content-for-madxartwork'), 'icon' => 'eicon-text-align-justify'], 'space-evenly' => ['title' => __('Evenly', 'dynamic-content-for-madxartwork'), 'icon' => 'eicon-text-align-justify'], 'space-between' => ['title' => __('Between', 'dynamic-content-for-madxartwork'), 'icon' => 'eicon-text-align-justify']], 'selectors' => ['{{WRAPPER}} {{CURRENT_ITEM}} .madxartwork-subgroup-inline' => 'width: 100%; justify-content: {{VALUE}};'], 'render_type' => 'ui', 'condition' => ['field_type' => ['checkbox', 'radio'], 'inline_list!' => ''], 'tabs_wrapper' => 'form_fields_tabs', 'inner_tab' => 'form_fields_enchanted_tab', 'tab' => 'enchanted');
        }
        return $control_data;
    }
}
