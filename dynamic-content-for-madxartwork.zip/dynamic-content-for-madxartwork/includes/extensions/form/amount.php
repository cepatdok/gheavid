<?php

namespace DynamicContentFormadxartwork\Extensions;

use madxartworkPro\Plugin as ProPlugin;
use madxartwork\Controls_Manager;
use madxartwork\Controls_Stack;
use DynamicContentFormadxartwork\Helper;
use DynamicContentFormadxartwork\Tokens;
use madxartwork\Group_Control_Border;
use madxartwork\Group_Control_Typography;
use madxartwork\Group_Control_Text_Shadow;
use madxartwork\Group_Control_Background;
use madxartwork\Group_Control_Box_Shadow;
if (!\defined('ABSPATH')) {
    exit;
    // Exit if accessed directly
}
class DCE_Extension_Form_Amount extends \madxartworkPro\Modules\Forms\Fields\Field_Base
{
    public $depended_scripts = ['dce-amount-field'];
    public function __construct()
    {
        add_action('madxartwork/element/form/section_steps_style/after_section_end', [$this, 'add_style_controls']);
        add_action('madxartwork/widget/print_template', function ($template, $widget) {
            if ('form' === $widget->get_name()) {
                $template = \false;
            }
            return $template;
        }, 10, 2);
        parent::__construct();
    }
    public function get_script_depends()
    {
        return $this->depended_scripts;
    }
    public function get_name()
    {
        return 'Amount';
    }
    public function get_type()
    {
        return 'amount';
    }
    public function get_style_depends()
    {
        return $this->depended_styles;
    }
    public function update_controls($widget)
    {
        if (!current_user_can('administrator') && \madxartwork\Plugin::$instance->editor->is_edit_mode()) {
            return;
        }
        $field_controlsor = ProPlugin::madxartwork();
        $control_data = $field_controlsor->controls_manager->get_control_from_stack($widget->get_unique_name(), 'form_fields');
        if (is_wp_error($control_data)) {
            return;
        }
        $field_controls = ['dce_amount_expression' => ['name' => 'dce_amount_expression', 'label' => __('Amount Expression', 'dynamic-content-for-madxartwork'), 'type' => Controls_Manager::TEXT, 'placeholder' => __('[form:field_1] * [form:field_2] + 1.4', 'dynamic-content-for-madxartwork'), 'label_block' => \true, 'conditions' => ['terms' => [['name' => 'field_type', 'value' => 'amount']]], 'frontend_available' => \true, 'tabs_wrapper' => 'form_fields_tabs', 'tab' => 'content', 'inner_tab' => 'form_fields_content_tab'], 'dce_amount_text_before' => ['name' => 'dce_amount_text_before', 'label' => __('Text Before', 'dynamic-content-for-madxartwork'), 'type' => Controls_Manager::TEXT, 'conditions' => ['terms' => [['name' => 'field_type', 'value' => 'amount']]], 'frontend_available' => \true, 'tabs_wrapper' => 'form_fields_tabs', 'tab' => 'content', 'inner_tab' => 'form_fields_content_tab'], 'dce_amount_text_after' => ['name' => 'dce_amount_text_after', 'label' => __('Text After', 'dynamic-content-for-madxartwork'), 'type' => Controls_Manager::TEXT, 'conditions' => ['terms' => [['name' => 'field_type', 'value' => 'amount']]], 'frontend_available' => \true, 'tabs_wrapper' => 'form_fields_tabs', 'tab' => 'content', 'inner_tab' => 'form_fields_content_tab'], 'dce_amount_hide' => ['name' => 'dce_amount_hide', 'label' => __('Hide Amount', 'dynamic-content-for-madxartwork'), 'type' => Controls_Manager::SWITCHER, 'description' => __('Do not display Amount value in frontend form, use its value only in Actions (like Email)', 'dynamic-content-for-madxartwork'), 'conditions' => ['terms' => [['name' => 'field_type', 'value' => 'amount']]], 'frontend_available' => \true, 'tabs_wrapper' => 'form_fields_tabs', 'tab' => 'content', 'inner_tab' => 'form_fields_content_tab']];
        $control_data['fields'] = $this->inject_field_controls($control_data['fields'], $field_controls);
        $widget->update_control('form_fields', $control_data);
    }
    public function add_style_controls($widget)
    {
        $widget->start_controls_section('dce_amount_section_style', ['label' => __('Amount', 'dynamic-content-for-madxartwork'), 'tab' => Controls_Manager::TAB_STYLE]);
        $widget->add_control('dce_amount_heading_input', ['label' => __('Input', 'dynamic-content-for-madxartwork'), 'type' => Controls_Manager::HEADING]);
        $widget->add_responsive_control('dce_amount_align', ['label' => __('Alignment', 'dynamic-content-for-madxartwork'), 'type' => Controls_Manager::CHOOSE, 'options' => ['left' => ['title' => __('Left', 'dynamic-content-for-madxartwork'), 'icon' => 'fa fa-align-left'], 'center' => ['title' => __('Center', 'dynamic-content-for-madxartwork'), 'icon' => 'fa fa-align-center'], 'right' => ['title' => __('Right', 'dynamic-content-for-madxartwork'), 'icon' => 'fa fa-align-right']], 'selectors' => ['{{WRAPPER}} .madxartwork-field-type-amount.madxartwork-field-group:not(.madxartwork-field-type-upload) .madxartwork-field:not(.madxartwork-select-wrapper)' => 'text-align: {{VALUE}};']]);
        $widget->add_responsive_control('dce_amount_opacity', ['label' => __('Opacity (%)', 'dynamic-content-for-madxartwork'), 'type' => Controls_Manager::SLIDER, 'default' => ['size' => 1], 'range' => ['px' => ['max' => 1, 'min' => 0.1, 'step' => 0.01]], 'selectors' => ['{{WRAPPER}} .madxartwork-field-type-amount.madxartwork-field-group:not(.madxartwork-field-type-upload) .madxartwork-field:not(.madxartwork-select-wrapper)' => 'opacity: {{SIZE}};']]);
        $widget->add_responsive_control('dce_amount_padding', ['label' => __('Padding', 'dynamic-content-for-madxartwork'), 'type' => Controls_Manager::DIMENSIONS, 'size_units' => ['px', '%', 'em'], 'selectors' => ['{{WRAPPER}} .madxartwork-field-type-amount.madxartwork-field-group:not(.madxartwork-field-type-upload) .madxartwork-field:not(.madxartwork-select-wrapper)' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};']]);
        $widget->add_responsive_control('dce_amount_margin', ['label' => __('Margin', 'dynamic-content-for-madxartwork'), 'type' => Controls_Manager::DIMENSIONS, 'size_units' => ['px', '%', 'em'], 'selectors' => ['{{WRAPPER}} .madxartwork-field-type-amount.madxartwork-field-group:not(.madxartwork-field-type-upload) .madxartwork-field:not(.madxartwork-select-wrapper)' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};']]);
        $widget->add_control('dce_amount_color', ['label' => __('Color', 'dynamic-content-for-madxartwork'), 'type' => Controls_Manager::COLOR, 'selectors' => ['{{WRAPPER}} .madxartwork-field-type-amount.madxartwork-field-group:not(.madxartwork-field-type-upload) .madxartwork-field:not(.madxartwork-select-wrapper)' => 'color: {{VALUE}};']]);
        $widget->add_group_control(Group_Control_Typography::get_type(), ['name' => 'dce_amount_typography', 'label' => __('Typography', 'dynamic-content-for-madxartwork'), 'selector' => '{{WRAPPER}} .madxartwork-field-type-amount.madxartwork-field-group:not(.madxartwork-field-type-upload) .madxartwork-field:not(.madxartwork-select-wrapper)']);
        $widget->add_responsive_control('dce_amount_position', ['label' => __('Position', 'dynamic-content-for-madxartwork'), 'type' => Controls_Manager::CHOOSE, 'options' => ['row-reverse' => ['title' => __('Left', 'dynamic-content-for-madxartwork'), 'icon' => 'fa fa-align-left'], 'row' => ['title' => __('Right', 'dynamic-content-for-madxartwork'), 'icon' => 'fa fa-align-right']], 'default' => 'row', 'selectors' => ['{{WRAPPER}} .madxartwork-field-group.madxartwork-field-type-amount' => 'flex-direction: {{VALUE}};']]);
        $widget->add_control('dce_amount_space', ['label' => __('Width', 'dynamic-content-for-madxartwork'), 'type' => Controls_Manager::SLIDER, 'default' => ['size' => 100], 'range' => ['%' => ['min' => 20, 'max' => 100]], 'selectors' => ['{{WRAPPER}} .madxartwork-field-type-amount.madxartwork-field-group:not(.madxartwork-field-type-upload) .madxartwork-field:not(.madxartwork-select-wrapper)' => 'flex-basis: {{SIZE}}%; max-width: {{SIZE}}%;']]);
        $widget->add_group_control(Group_Control_Border::get_type(), ['name' => 'dce_amount_border', 'label' => __('Border', 'dynamic-content-for-madxartwork'), 'selector' => '{{WRAPPER}} .madxartwork-field-type-amount.madxartwork-field-group:not(.madxartwork-field-type-upload) .madxartwork-field:not(.madxartwork-select-wrapper)']);
        $widget->add_control('dce_amount_border_radius', ['label' => __('Border Radius', 'dynamic-content-for-madxartwork'), 'type' => Controls_Manager::DIMENSIONS, 'size_units' => ['px', '%'], 'selectors' => ['{{WRAPPER}} .madxartwork-field-type-amount.madxartwork-field-group:not(.madxartwork-field-type-upload) .madxartwork-field:not(.madxartwork-select-wrapper)' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};']]);
        $widget->add_group_control(Group_Control_Background::get_type(), ['name' => 'dce_amount_background', 'types' => ['classic', 'gradient'], 'selector' => '{{WRAPPER}} .madxartwork-field-type-amount.madxartwork-field-group:not(.madxartwork-field-type-upload) .madxartwork-field:not(.madxartwork-select-wrapper)']);
        $widget->add_control('dce_amount_heading_title', ['label' => __('Label', 'dynamic-content-for-madxartwork'), 'type' => Controls_Manager::HEADING, 'separator' => 'before']);
        $widget->add_responsive_control('dce_amount_title_align', ['label' => __('Alignment', 'dynamic-content-for-madxartwork'), 'type' => Controls_Manager::CHOOSE, 'options' => ['left' => ['title' => __('Left', 'dynamic-content-for-madxartwork'), 'icon' => 'fa fa-align-left'], 'center' => ['title' => __('Center', 'dynamic-content-for-madxartwork'), 'icon' => 'fa fa-align-center'], 'right' => ['title' => __('Right', 'dynamic-content-for-madxartwork'), 'icon' => 'fa fa-align-right']], 'selectors' => ['{{WRAPPER}} .madxartwork-field-group.madxartwork-field-type-amount > label.madxartwork-field-label' => 'width: 100%; text-align: {{VALUE}};']]);
        $widget->add_control('dce_amount_title_color', ['label' => __('Color', 'dynamic-content-for-madxartwork'), 'type' => Controls_Manager::COLOR, 'selectors' => ['{{WRAPPER}} .madxartwork-field-group.madxartwork-field-type-amount > label.madxartwork-field-label' => 'color: {{VALUE}};']]);
        $widget->add_group_control(Group_Control_Typography::get_type(), ['name' => 'dce_amount_title_typography', 'label' => __('Typography', 'dynamic-content-for-madxartwork'), 'selector' => '{{WRAPPER}} .madxartwork-field-group.madxartwork-field-type-amount > label.madxartwork-field-label']);
        $widget->add_group_control(Group_Control_Text_Shadow::get_type(), ['name' => 'dce_amount_text_shadow', 'selector' => '{{WRAPPER}} .madxartwork-field-group.madxartwork-field-type-amount > label.madxartwork-field-label']);
        $widget->end_controls_section();
    }
    public function render($item, $item_index, $form)
    {
        $method = $form->get_settings('form_method');
        if ($method === 'post' || $method === 'get') {
            echo '<p><span class="madxartwork-message madxartwork-message-danger madxartwork-help-inline madxartwork-form-help-inline" role="alert">';
            echo __('Amount is not compatible with the Method Extension Post and Get options.', 'dynamic-content-for-madxartwork');
            echo '</span></p>';
            return;
        }
        $expression = $item['dce_amount_expression'];
        $expression = \preg_replace('/\\[form:([^\\]]+)\\]/', ' getField("\\1") ', $expression);
        $expression = \preg_replace('/\\[field\\s+id\\s*=\\s*"([^"]+)"\\s*\\]/', ' getField("\\1") ', $expression);
        $full_code = <<<EOD
dceAmountField.registerRefresherGenerator("{$item['custom_id']}", (getField) => {
\t\treturn () => { return {$expression}; };
})
EOD;
        wp_add_inline_script('dce-amount-field', $full_code, 'after');
        wp_localize_script('dce-amount-field', 'amountFieldLocale', ['syntaxError' => __('Your Amount Field code contains errors, check the browser console!', 'dynamic-content-for-madxartwork')]);
        if ($item['dce_amount_hide'] === 'yes') {
            $form->add_render_attribute('input' . $item_index, 'data-hide', 'yes');
        }
        // Real input (hidden)
        $form->add_render_attribute('input' . $item_index, 'data-field-id', $item['custom_id']);
        $form->add_render_attribute('input' . $item_index, 'data-text-before', $item['dce_amount_text_before'] ?? '');
        $form->add_render_attribute('input' . $item_index, 'data-text-after', $item['dce_amount_text_after'] ?? '');
        $form->add_render_attribute('input' . $item_index, 'type', 'hidden');
        $form->add_render_attribute('input' . $item_index, 'class', 'dce-amount-hidden');
        $form->add_render_attribute('input' . $item_index, 'style', 'display: none;');
        // Visibile input, can have text before and after.
        $form->add_render_attribute('v-input' . $item_index, 'type', 'text');
        $form->add_render_attribute('v-input' . $item_index, 'class', 'dce-amount-visible');
        $form->add_render_attribute('v-input' . $item_index, 'class', 'madxartwork-field-textual');
        $form->add_render_attribute('v-input' . $item_index, 'readonly', '');
        echo '<input ' . $form->get_render_attribute_string('input' . $item_index) . '>';
        echo '<input size="1"' . $form->get_render_attribute_string('v-input' . $item_index) . '>';
    }
}
