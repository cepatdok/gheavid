<?php

namespace DynamicContentFormadxartwork\Extensions;

use madxartwork\Core\Kits\Documents\Tabs\Global_Colors;
use madxartwork\Controls_Manager;
use madxartwork\Controls_Stack;
use DynamicContentFormadxartwork\Helper;
use DynamicContentFormadxartwork\Tokens;
use madxartwork\Group_Control_Border;
use madxartwork\Group_Control_Typography;
use madxartwork\Group_Control_Text_Shadow;
use madxartwork\Group_Control_Background;
use madxartwork\Group_Control_Box_Shadow;
use madxartworkPro\Modules\Forms\Fields;
use madxartwork\Widget_Base;
use madxartworkPro\Modules\Forms\Classes;
use madxartworkPro\Modules\Forms\Widgets\Form;
use madxartworkPro\Plugin;
if (!\defined('ABSPATH')) {
    exit;
    // Exit if accessed directly
}
class LiveHtml extends \madxartworkPro\Modules\Forms\Fields\Field_Base
{
    public $depended_scripts = ['dce-live-html'];
    public function __construct()
    {
        // Make it so madxartwork doesn't render the label.
        $field_type = $this->get_type();
        add_filter("madxartwork_pro/forms/render/item/{$field_type}", function ($item) {
            $item['field_label'] = '';
            return $item;
        }, 10, 1);
        add_action('madxartwork/widget/print_template', function ($template, $widget) {
            if ('form' === $widget->get_name()) {
                $template = \false;
            }
            return $template;
        }, 10, 2);
        parent::__construct();
    }
    public function get_script_depends()
    {
        return $this->depended_scripts;
    }
    public function get_name()
    {
        return 'Live HTML';
    }
    public function get_label()
    {
        return __('Live HTML', 'dynamic-content-for-madxartwork');
    }
    public function get_type()
    {
        return 'dce_live_html';
    }
    public function get_style_depends()
    {
        return $this->depended_styles;
    }
    public function update_controls($widget)
    {
        if (!current_user_can('administrator') && \madxartwork\Plugin::$instance->editor->is_edit_mode()) {
            return;
        }
        $madxartwork = Plugin::madxartwork();
        $control_data = $madxartwork->controls_manager->get_control_from_stack($widget->get_unique_name(), 'form_fields');
        if (is_wp_error($control_data)) {
            return;
        }
        $field_controls = ['dce_live_html' => ['name' => 'dce_live_html', 'label' => __('HTML', 'dynamic-content-for-madxartwork'), 'description' => __('', 'dynamic-content-for-madxartwork'), 'type' => \madxartwork\Controls_Manager::CODE, 'default' => 'Hi {{ form.name }}', 'language' => 'html', 'label_block' => 'true', 'tab' => 'content', 'inner_tab' => 'form_fields_content_tab', 'tabs_wrapper' => 'form_fields_tabs', 'condition' => ['field_type' => $this->get_type()]], 'dce_live_html_real_time' => ['name' => 'dce_live_html_real_time', 'label' => __('Update on each Keypress', 'dynamic-content-for-madxartwork'), 'type' => Controls_Manager::SWITCHER, 'description' => __('Do not wait for the field to be blurred for the event to be triggered. Do it on each keypress.', 'dynamic-content-for-madxartwork'), 'tab' => 'content', 'inner_tab' => 'form_fields_content_tab', 'tabs_wrapper' => 'form_fields_tabs', 'condition' => ['field_type' => $this->get_type()]]];
        $control_data['fields'] = $this->inject_field_controls($control_data['fields'], $field_controls);
        $widget->update_control('form_fields', $control_data);
    }
    /**
     * @param      $item
     * @param      $item_index
     * @param Form $form
     */
    public function render($item, $item_index, $form)
    {
        $form->add_render_attribute('div' . $item_index, 'data-code', do_shortcode($item['dce_live_html']));
        $form->add_render_attribute('div' . $item_index, 'class', 'dce-live-html-wrapper');
        $form->add_render_attribute('div' . $item_index, 'data-real-time', $item['dce_live_html_real_time'] ?? 'no');
        echo '<div ' . $form->get_render_attribute_string('div' . $item_index) . '></div>';
    }
}
