<?php

namespace DynamicContentFormadxartwork\Extensions;

use madxartwork\Controls_Manager;
use madxartwork\Controls_Stack;
use DynamicContentFormadxartwork\Helper;
use DynamicContentFormadxartwork\Tokens;
if (!\defined('ABSPATH')) {
    exit;
}
// Exit if accessed directly
class ConfirmDialog extends \DynamicContentFormadxartwork\Extensions\DCE_Extension_Prototype
{
    private static $actions_added = \false;
    public static $depended_plugins = ['madxartwork-pro'];
    private $is_common = \false;
    public $has_action = \false;
    public $depended_scripts = ['dce-confirm-dialog'];
    public $depended_styles = ['dce-jquery-confirm'];
    public function get_label()
    {
        return __('Confirm Dialog', 'dynamic-content-for-madxartwork');
    }
    public function add_assets_depends($instance, $form)
    {
        foreach ($this->depended_scripts as $script) {
            $form->add_script_depends($script);
        }
        foreach ($this->depended_styles as $style) {
            $form->add_style_depends($style);
        }
    }
    protected function add_actions()
    {
        if (self::$actions_added) {
            return;
        }
        self::$actions_added = \true;
        add_action('madxartwork-pro/forms/pre_render', [$this, 'add_assets_depends'], 10, 2);
        add_action('madxartwork/element/form/section_buttons/after_section_end', [$this, 'add_controls_to_form']);
    }
    public function add_controls_to_form($widget)
    {
        if (!current_user_can('administrator') && \madxartwork\Plugin::$instance->editor->is_edit_mode()) {
            return;
        }
        $widget->start_controls_section('section_dce_confirm_dialog', ['label' => '<span class="color-dce icon icon-dyn-logo-dce pull-right ml-1"></span> ' . __('Confirm Dialog before Submit', 'dynamic-content-for-madxartwork')]);
        $widget->add_control('dce_confirm_dialog_enabled', ['label' => __('Confirm Dialog', 'dynamic-content-for-madxartwork'), 'type' => Controls_Manager::SWITCHER, 'return_value' => 'yes', 'default' => 'no', 'frontend_available' => \true]);
        $widget->add_control('dce_confirm_dialog_title', ['label' => __('Title', 'dynamic-content-for-madxartwork'), 'type' => \madxartwork\Controls_Manager::TEXT, 'default' => 'Confirm', 'label_block' => 'true', 'description' => __('You can use the same syntax as in Dynamic.ooo Live HTML field.', 'dynamic-content-for-madxartwork'), 'condition' => ['dce_confirm_dialog_enabled' => 'yes'], 'frontend_available' => \true]);
        $widget->add_control('dce_confirm_dialog_content', ['label' => __('Content', 'dynamic-content-for-madxartwork'), 'type' => \madxartwork\Controls_Manager::CODE, 'default' => 'Hi {{ form.name }}, please confirm submission', 'language' => 'html', 'label_block' => 'true', 'description' => __('HTML code to be displayed in the modal. You can use the same syntax as in Dynamic.ooo Live HTML field.', 'dynamic-content-for-madxartwork'), 'condition' => ['dce_confirm_dialog_enabled' => 'yes'], 'frontend_available' => \true]);
        $widget->add_control('dce_confirm_dialog_theme', ['label' => __('Theme', 'dynamic-content-for-madxartwork'), 'type' => \madxartwork\Controls_Manager::SELECT, 'default' => 'light', 'options' => ['light' => __('Light', 'dynamic-content-for-madxartwork'), 'dark' => __('Dark', 'dynamic-content-for-madxartwork'), 'material' => 'Material', 'supervan' => 'Supervan', 'bootstrap' => 'Bootstrap'], 'separator' => 'after', 'label_block' => 'true', 'condition' => ['dce_confirm_dialog_enabled' => 'yes'], 'frontend_available' => \true]);
        $widget->end_controls_section();
    }
}
