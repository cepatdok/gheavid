<?php

namespace DynamicContentFormadxartwork\Extensions;

use madxartwork\Controls_Manager;
use madxartwork\Controls_Stack;
use madxartwork\Group_Control_Typography;
use madxartwork\Group_Control_Border;
use madxartwork\Icons_Manager;
use DynamicContentFormadxartwork\Helper;
if (!\defined('ABSPATH')) {
    exit;
    // Exit if accessed directly
}
class DCE_Extension_Form_Select2 extends \DynamicContentFormadxartwork\Extensions\DCE_Extension_Prototype
{
    private $is_common = \false;
    public $has_action = \false;
    public function get_name()
    {
        return 'dce_form_select2';
    }
    public function get_label()
    {
        return __('Select2', 'dynamic-content-for-madxartwork');
    }
    protected function add_actions()
    {
        add_action('madxartwork/widget/render_content', array($this, '_render_form'), 10, 2);
        add_action('madxartwork/widget/print_template', function ($template, $widget) {
            if ('form' === $widget->get_name()) {
                $template = \false;
            }
            return $template;
        }, 10, 2);
        if (!is_admin()) {
            wp_register_script('jquery-madxartwork-select2', madxartwork_ASSETS_URL . 'lib/e-select2/js/e-select2.full.min.js', ['jquery'], '4.0.6-rc.1', \true);
            wp_register_style('madxartwork-select2', madxartwork_ASSETS_URL . 'lib/e-select2/css/e-select2.min.css', [], '4.0.6-rc.1');
            wp_register_style('font-awesome', madxartwork_ASSETS_URL . 'lib/font-awesome/css/font-awesome.min.css', [], '4.7.0');
            wp_register_style('fontawesome', madxartwork_ASSETS_URL . 'lib/font-awesome/css/fontawesome.min.css', [], '5.9.0');
        }
    }
    public function _render_form($content, $widget)
    {
        if ($widget->get_name() == 'form') {
            $settings = $widget->get_settings_for_display();
            $jkey = 'dce_' . $widget->get_type() . '_form_' . $widget->get_id() . '_select2';
            \ob_start();
            ?>
			<script id="<?php 
            echo $jkey;
            ?>">
				(function ($) {
			<?php 
            if (!\madxartwork\Plugin::$instance->editor->is_edit_mode()) {
                ?>
					var <?php 
                echo $jkey;
                ?> = function ($scope, $) {
						if ($scope.hasClass("madxartwork-element-<?php 
                echo $widget->get_id();
                ?>")) {
				<?php 
            }
            $has_select2 = \false;
            foreach ($settings['form_fields'] as $key => $afield) {
                if ($afield['field_type'] == 'select') {
                    if (!empty($afield['field_select2'])) {
                        $has_select2 = \true;
                        ?>
					if (jQuery.fn.select2) {
						var field2 = jQuery('.madxartwork-element-<?php 
                        echo $widget->get_id();
                        ?> #form-field-<?php 
                        echo $afield['custom_id'];
                        ?>');
						let form = $scope.find('form')[0];
						field2.on('select2:select', () => {
							let evtChange = document.createEvent("HTMLEvents");
							evtChange.initEvent("change", false, true);
							let evtInput = document.createEvent("HTMLEvents");
							evtInput.initEvent("input", false, true);
							form.dispatchEvent(evtChange);
							form.dispatchEvent(evtInput);
						});
						var classes = field2.attr('class');
						var $select2 = field2.select2({
							//containerCssClass: classes,
						<?php 
                        if (!empty($afield['field_select2_placeholder'])) {
                            ?>placeholder: '<?php 
                            echo $afield['field_select2_placeholder'];
                            ?>',<?php 
                        }
                        ?>
									});
									$select2.data('select2').$container.find('.select2-selection').addClass(classes);
								}
						<?php 
                    }
                }
            }
            ?>
				jQuery('.madxartwork-element-<?php 
            echo $widget->get_id();
            ?> .select2-selection__arrow').remove();
			<?php 
            if (!\madxartwork\Plugin::$instance->editor->is_edit_mode()) {
                ?>
				}
				};
				$(window).on("madxartwork/frontend/init", function () {
					madxartworkFrontend.hooks.addAction("frontend/element_ready/form.default", <?php 
                echo $jkey;
                ?>);
				});
		  	<?php 
            }
            ?>
						 	 })(jQuery, window);
		  	</script>
			<?php 
            $add_js = \ob_get_clean();
            if ($has_select2) {
                $add_js = \DynamicContentFormadxartwork\Assets::dce_enqueue_script($jkey, $add_js);
                wp_enqueue_script('jquery-madxartwork-select2');
                wp_enqueue_style('madxartwork-select2');
                return $content . $add_js;
            }
        }
        return $content;
    }
    public static function _add_to_form(Controls_Stack $element, $control_id, $control_data, $options = [])
    {
        if ($element->get_name() == 'form') {
            if ($control_id == 'form_fields') {
                $control_data['fields']['field_select2'] = array('name' => 'field_select2', 'label' => __('Select2', 'dynamic-content-for-madxartwork'), 'type' => Controls_Manager::SWITCHER, 'separator' => 'before', 'return_value' => 'true', 'conditions' => ['terms' => [['name' => 'field_type', 'value' => 'select']]], 'tabs_wrapper' => 'form_fields_tabs', 'inner_tab' => 'form_fields_enchanted_tab', 'tab' => 'enchanted');
                $control_data['fields']['field_select2_placeholder'] = array('name' => 'field_select2_placeholder', 'label' => __('Placeholder', 'dynamic-content-for-madxartwork'), 'type' => Controls_Manager::TEXT, 'conditions' => ['terms' => [['name' => 'field_type', 'value' => 'select'], ['name' => 'field_select2', 'value' => 'true']]], 'tabs_wrapper' => 'form_fields_tabs', 'inner_tab' => 'form_fields_enchanted_tab', 'tab' => 'enchanted');
            }
            if ($control_id == 'field_text_color') {
                $control_data['selectors']['{{WRAPPER}} .select2-container--default .select2-selection--single .select2-selection__rendered'] = 'color: {{VALUE}};';
                $control_data['selectors']['{{WRAPPER}} ..select2-container--default .select2-selection--multiple .select2-selection__rendered'] = 'color: {{VALUE}};';
            }
            if (\strpos($control_id, 'field_typography') === 0) {
                if (!empty($control_data['selectors'])) {
                    $values = \reset($control_data['selectors']);
                    $control_data['selectors']['{{WRAPPER}} .select2-container--default .select2-selection--single .select2-selection__rendered'] = $values;
                    $control_data['selectors']['{{WRAPPER}} .select2-container--default .select2-selection--single .select2-selection__rendered'] = $values;
                    $control_data['selectors']['{{WRAPPER}} .select2-container--default .select2-selection--single, {{WRAPPER}} .select2-container--default .select2-selection--multiple'] = 'height: auto;';
                }
            }
            if ($control_id == 'field_background_color') {
                $control_data['selectors']['{{WRAPPER}} .madxartwork-field-group .madxartwork-select-wrapper .select2'] = 'background-color: {{VALUE}};';
                $control_data['selectors']['{{WRAPPER}} .madxartwork-field-group .madxartwork-select-wrapper .select2 .madxartwork-field-textual'] = 'background-color: {{VALUE}};';
                $control_data['selectors']['{{WRAPPER}} .mce-panel'] = 'background-color: {{VALUE}};';
            }
            if ($control_id == 'field_border_color') {
                $control_data['selectors']['{{WRAPPER}} .madxartwork-field-group .madxartwork-select-wrapper .select2'] = 'border-color: {{VALUE}};';
                $control_data['selectors']['{{WRAPPER}} .madxartwork-field-group .madxartwork-select-wrapper .select2 .madxartwork-field-textual'] = 'border-color: {{VALUE}};';
                $control_data['selectors']['{{WRAPPER}} .madxartwork-field-group .mce-panel'] = 'border-color: {{VALUE}};';
            }
            if ($control_id == 'field_border_width') {
                $control_data['selectors']['{{WRAPPER}} .madxartwork-field-group .madxartwork-select-wrapper .select2'] = 'border-width: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};';
                $control_data['selectors']['{{WRAPPER}} .madxartwork-field-group .madxartwork-select-wrapper .select2 .madxartwork-field-textual'] = 'border-width: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};';
                $control_data['selectors']['{{WRAPPER}} .madxartwork-field-group .mce-panel'] = 'border-width: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};';
            }
            if ($control_id == 'field_border_radius') {
                $control_data['selectors']['{{WRAPPER}} .madxartwork-field-group .madxartwork-select-wrapper .select2'] = 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};';
                $control_data['selectors']['{{WRAPPER}} .madxartwork-field-group .madxartwork-select-wrapper .select2 .madxartwork-field-textual'] = 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};';
                $control_data['selectors']['{{WRAPPER}} .madxartwork-field-group .mce-panel'] = 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};';
            }
        }
        return $control_data;
    }
}
