<?php

namespace DynamicContentFormadxartwork\Extensions;

use madxartwork\Controls_Manager;
use madxartwork\Controls_Stack;
use madxartwork\Group_Control_Typography;
use madxartwork\Group_Control_Border;
use madxartwork\Icons_Manager;
use DynamicContentFormadxartwork\Helper;
if (!\defined('ABSPATH')) {
    exit;
    // Exit if accessed directly
}
class DCE_Extension_Form_Submit_On_Change extends \DynamicContentFormadxartwork\Extensions\DCE_Extension_Prototype
{
    private $is_common = \false;
    public $has_action = \false;
    public function get_name()
    {
        return 'dce_form_onchange';
    }
    public function get_label()
    {
        return __('Onchange', 'dynamic-content-for-madxartwork');
    }
    protected function add_actions()
    {
        add_action('madxartwork/widget/render_content', array($this, '_render_form'), 10, 2);
        add_action('madxartwork/element/form/section_form_fields/before_section_end', [$this, 'update_fields_controls']);
        add_action('madxartwork/widget/print_template', function ($template, $widget) {
            if ('form' === $widget->get_name()) {
                $template = \false;
            }
            return $template;
        }, 10, 2);
    }
    public function _render_form($content, $widget)
    {
        if ($widget->get_name() == 'form') {
            $settings = $widget->get_settings_for_display();
            $jkey = 'dce_' . $widget->get_type() . '_form_' . $widget->get_id() . '_onchange';
            \ob_start();
            ?>
		  <script id="<?php 
            echo $jkey;
            ?>">
			  (function ($) {
			<?php 
            if (!\madxartwork\Plugin::$instance->editor->is_edit_mode()) {
                ?>
					  var <?php 
                echo $jkey;
                ?> = function ($scope, $) {
						  if ($scope.hasClass("madxartwork-element-<?php 
                echo $widget->get_id();
                ?>")) {
				<?php 
            }
            $has_onchange = \false;
            foreach ($settings['form_fields'] as $key => $afield) {
                if (!empty($afield['field_onchange'])) {
                    $has_onchange = \true;
                    ?>
				  jQuery('.madxartwork-element-<?php 
                    echo $widget->get_id();
                    ?> .madxartwork-field-group-<?php 
                    echo $afield['custom_id'];
                    ?> input, .madxartwork-element-<?php 
                    echo $widget->get_id();
                    ?> .madxartwork-field-group-<?php 
                    echo $afield['custom_id'];
                    ?> select').on('change', function () {
					  var field = jQuery(this).closest('.madxartwork-field-group');
					  if (field.siblings('.dce-form-step-bnt-next').length) {
						  // step
						  field.siblings('.dce-form-step-bnt-next').find('button').trigger('click');
					  } else {
						  // submit
						  jQuery(this).closest('form').find('.madxartwork-field-type-submit button').trigger('click');
					  }
				  });
					<?php 
                }
            }
            ?>
						  jQuery('.madxartwork-element-<?php 
            echo $widget->get_id();
            ?> .select2-selection__arrow').remove();
			<?php 
            if (!\madxartwork\Plugin::$instance->editor->is_edit_mode()) {
                ?>
						  }
					  };
					  $(window).on("madxartwork/frontend/init", function () {
						  madxartworkFrontend.hooks.addAction("frontend/element_ready/form.default", <?php 
                echo $jkey;
                ?>);
					  });
		  <?php 
            }
            ?>
			  })(jQuery, window);
		  </script>
			<?php 
            $add_js = \ob_get_clean();
            if ($has_onchange) {
                $add_js = \DynamicContentFormadxartwork\Assets::dce_enqueue_script($jkey, $add_js);
                return $content . $add_js;
            }
        }
        return $content;
    }
    public function update_fields_controls($widget)
    {
        $madxartwork = \madxartworkPro\Plugin::madxartwork();
        $control_data = $madxartwork->controls_manager->get_control_from_stack($widget->get_unique_name(), 'form_fields');
        if (is_wp_error($control_data)) {
            return;
        }
        $field_controls = ['field_onchange' => ['name' => 'field_onchange', 'label' => __('Submit on Change', 'dynamic-content-for-madxartwork'), 'type' => Controls_Manager::SWITCHER, 'separator' => 'before', 'condition' => ['field_type' => ['radio', 'select']], 'tabs_wrapper' => 'form_fields_tabs', 'inner_tab' => 'form_fields_enchanted_tab', 'tab' => 'enchanted']];
        $control_data['fields'] = \array_merge($control_data['fields'], $field_controls);
        $widget->update_control('form_fields', $control_data);
    }
}
