<?php

namespace DynamicContentFormadxartwork\Extensions;

use madxartwork\Controls_Manager;
use madxartwork\Controls_Stack;
use madxartwork\Group_Control_Typography;
use madxartwork\Group_Control_Border;
use madxartwork\Icons_Manager;
use DynamicContentFormadxartwork\Helper;
if (!\defined('ABSPATH')) {
    exit;
    // Exit if accessed directly
}
class DCE_Extension_Form_Method extends \DynamicContentFormadxartwork\Extensions\DCE_Extension_Prototype
{
    private $is_common = \false;
    public $has_action = \false;
    /**
     * Get Name
     *
     * Return the action name
     *
     * @access public
     * @return string
     */
    public function get_name()
    {
        return 'dce_form_method';
    }
    /**
     * Get Label
     *
     * Returns the action label
     *
     * @access public
     * @return string
     */
    public function get_label()
    {
        return __('Method', 'dynamic-content-for-madxartwork');
    }
    /**
     * Add Actions
     *
     * @since 0.5.5
     *
     * @access private
     */
    protected function add_actions()
    {
        add_action('madxartwork/widget/render_content', array($this, '_render_form'), 10, 2);
        add_action('madxartwork/widget/print_template', function ($template, $widget) {
            if ('form' === $widget->get_name()) {
                $template = \false;
            }
            return $template;
        }, 10, 2);
    }
    public function _render_form($content, $widget)
    {
        if ($widget->get_name() == 'form') {
            $settings = $widget->get_settings_for_display();
            if (!empty($settings['form_method']) && $settings['form_method'] != 'ajax') {
                foreach ($settings['form_fields'] as $key => $afield) {
                    $content = \str_replace('form_fields[' . $afield['custom_id'] . ']', $afield['custom_id'], $content);
                }
                if ($settings['form_method'] == 'get') {
                    $content = \str_replace('method="post"', 'method="' . $settings['form_method'] . '"', $content);
                }
                if (!empty($settings['form_action']['url'])) {
                    $content = \str_replace('<form ', '<form action="' . $settings['form_action']['url'] . '" ', $content);
                } else {
                    $content = \str_replace('<form ', '<form action="" ', $content);
                    // current page
                }
                if ($settings['form_action']['custom_attributes']) {
                    $attr_str = '';
                    $attrs = Helper::str_to_array(',', $settings['form_action']['custom_attributes']);
                    if (!empty($attrs)) {
                        foreach ($attrs as $anattr) {
                            list($attr, $value) = \explode('|', $anattr, 2);
                            $attr_str .= $attr . '="' . $value . '" ';
                        }
                    }
                    if ($attr_str) {
                        $content = \str_replace('<form ', '<form ' . $attr_str, $content);
                    }
                }
                if (!empty($settings['form_action']['is_external'])) {
                    $content = \str_replace('<form ', '<form target="_blank" ', $content);
                }
                if (!empty($settings['form_action']['nofollow'])) {
                    $content = \str_replace('<form ', '<form rel="nofollow" ', $content);
                }
                $jkey = 'dce_' . $widget->get_type() . '_form_' . $widget->get_id() . '_action';
                \ob_start();
                ?>
				<script id="<?php 
                echo $jkey;
                ?>">
					(function ($) {
					<?php 
                if (!\madxartwork\Plugin::$instance->editor->is_edit_mode()) {
                    ?>
							var <?php 
                    echo $jkey;
                    ?> = function ($scope, $) {
								if ($scope.hasClass("madxartwork-element-<?php 
                    echo $widget->get_id();
                    ?>")) {
				<?php 
                }
                ?>
								jQuery('.madxartwork-element-<?php 
                echo $widget->get_id();
                ?> .madxartwork-form').off();
					<?php 
                if (!\madxartwork\Plugin::$instance->editor->is_edit_mode()) {
                    ?>
								}
							};
							$(window).on("madxartwork/frontend/init", function () {
								madxartworkFrontend.hooks.addAction("frontend/element_ready/form.default", <?php 
                    echo $jkey;
                    ?>);
							});
				<?php 
                }
                ?>
					})(jQuery, window);
				</script>
				<?php 
                $add_js = \ob_get_clean();
                $add_js = \DynamicContentFormadxartwork\Assets::dce_enqueue_script($jkey, $add_js);
                return $content . $add_js;
            }
        }
        return $content;
    }
    public static function _add_to_form(Controls_Stack $element, $control_id, $control_data, $options = [])
    {
        if (!current_user_can('administrator') && \madxartwork\Plugin::$instance->editor->is_edit_mode()) {
            return $control_data;
        }
        if ($element->get_name() == 'form' && $control_id == 'form_id') {
            $element->add_control('form_method', ['label' => '<span class="color-dce icon icon-dyn-logo-dce"></span> ' . __('Method', 'dynamic-content-for-madxartwork'), 'type' => Controls_Manager::CHOOSE, 'options' => ['ajax' => ['title' => __('AJAX (Default)', 'dynamic-content-for-madxartwork'), 'icon' => 'fa fa-retweet'], 'post' => ['title' => 'POST', 'icon' => 'fa fa-cog'], 'get' => ['title' => 'GET', 'icon' => 'fa fa-link']], 'toggle' => \false, 'default' => 'ajax']);
            $element->add_control('form_action_hide', ['type' => Controls_Manager::RAW_HTML, 'raw' => __('Using this method, all form Actions After Submit, validations, and conditional fields will not work!', 'dynamic-content-for-madxartwork'), 'content_classes' => 'madxartwork-panel-alert madxartwork-panel-alert-warning', 'condition' => ['form_method!' => 'ajax']]);
            $element->add_control('form_action', ['label' => __('Action', 'dynamic-content-for-madxartwork'), 'type' => Controls_Manager::URL, 'condition' => ['form_method!' => 'ajax']]);
            $control_data['separator'] = 'before';
        }
        return $control_data;
    }
}
