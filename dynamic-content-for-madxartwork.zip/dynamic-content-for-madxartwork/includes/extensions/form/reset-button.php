<?php

namespace DynamicContentFormadxartwork\Extensions;

use madxartwork\Controls_Manager;
use madxartwork\Controls_Stack;
use madxartwork\Group_Control_Typography;
use madxartwork\Group_Control_Border;
use madxartwork\Icons_Manager;
use DynamicContentFormadxartwork\Helper;
if (!\defined('ABSPATH')) {
    exit;
    // Exit if accessed directly
}
class DCE_Extension_Form_Reset extends \DynamicContentFormadxartwork\Extensions\DCE_Extension_Prototype
{
    private $is_common = \false;
    public $has_action = \false;
    /**
     * Get Name
     *
     * Return the action name
     *
     * @access public
     * @return string
     */
    public function get_name()
    {
        return 'dce_form_reset';
    }
    /**
     * Get Label
     *
     * Returns the action label
     *
     * @access public
     * @return string
     */
    public function get_label()
    {
        return __('Reset', 'dynamic-content-for-madxartwork');
    }
    /**
     * Add Actions
     *
     * @since 0.5.5
     *
     * @access private
     */
    protected function add_actions()
    {
        add_action('madxartwork/widget/render_content', array($this, '_render_form'), 10, 2);
        add_action('madxartwork_pro/forms/render_field/reset', array($this, '_render_reset'));
        add_action('madxartwork/element/form/section_button_style/after_section_end', array($this, '_add_form_reset_style'));
        add_action('madxartwork/widget/print_template', function ($template, $widget) {
            if ('form' === $widget->get_name()) {
                $template = \false;
            }
            return $template;
        }, 10, 2);
    }
    public function _render_reset($item, $item_index = 0, $form = null)
    {
        ?>
		<input type="reset" class="madxartwork-button-reset madxartwork-button madxartwork-size-<?php 
        echo $item['button_size'];
        ?>" value="<?php 
        echo $item['field_label'];
        ?>">
		<?php 
        return \true;
    }
    public function _render_form($content, $widget)
    {
        if ($widget->get_name() == 'form') {
            $settings = $widget->get_settings_for_display();
            $resets = \explode('madxartwork-field-type-reset', $content);
            if (\count($resets) > 1) {
                foreach ($resets as $rkey => $areset) {
                    if ($rkey) {
                        // remove label
                        $pieces = \explode('<label', $areset, 2);
                        if (\count($pieces) == 2) {
                            $more = \explode('</label>', \end($pieces), 2);
                            $content .= 'madxartwork-field-type-reset' . \reset($pieces) . \end($more);
                        } else {
                            $content .= 'madxartwork-field-type-reset' . $areset;
                        }
                    } else {
                        $content = $areset;
                    }
                }
            }
        }
        return $content;
    }
    public function _add_form_reset_style($element, $args = array())
    {
        if ($element->get_name() == 'form') {
            $element->start_controls_section('section_reset_button_style', ['label' => __('Reset Button', 'dynamic-content-for-madxartwork'), 'tab' => Controls_Manager::TAB_STYLE]);
            $element->start_controls_tabs('tabs_reset_button_style');
            $element->start_controls_tab('tab_reset_button_normal', ['label' => __('Normal', 'dynamic-content-for-madxartwork')]);
            $element->add_control('reset_button_background_color', ['label' => __('Background Color', 'dynamic-content-for-madxartwork'), 'type' => Controls_Manager::COLOR, 'selectors' => ['{{WRAPPER}} .madxartwork-button.madxartwork-button-reset' => 'background-color: {{VALUE}};']]);
            $element->add_control('reset_button_text_color', ['label' => __('Text Color', 'dynamic-content-for-madxartwork'), 'type' => Controls_Manager::COLOR, 'default' => '', 'selectors' => ['{{WRAPPER}} .madxartwork-button.madxartwork-button-reset' => 'color: {{VALUE}};', '{{WRAPPER}} .madxartwork-button.madxartwork-button-reset svg' => 'fill: {{VALUE}};']]);
            $element->add_group_control(Group_Control_Typography::get_type(), ['name' => 'reset_button_typography', 'selector' => '{{WRAPPER}} .madxartwork-button.madxartwork-button-reset']);
            $element->add_group_control(Group_Control_Border::get_type(), ['name' => 'reset_button_border', 'selector' => '{{WRAPPER}} .madxartwork-button.madxartwork-button-reset']);
            $element->add_control('reset_button_border_radius', ['label' => __('Border Radius', 'dynamic-content-for-madxartwork'), 'type' => Controls_Manager::DIMENSIONS, 'size_units' => ['px', '%'], 'selectors' => ['{{WRAPPER}} .madxartwork-button.madxartwork-button-reset' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};']]);
            $element->add_control('reset_button_text_padding', ['label' => __('Text Padding', 'dynamic-content-for-madxartwork'), 'type' => Controls_Manager::DIMENSIONS, 'size_units' => ['px', 'em', '%'], 'selectors' => ['{{WRAPPER}} .madxartwork-button.madxartwork-button-reset' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};']]);
            $element->end_controls_tab();
            $element->start_controls_tab('tab_reset_button_hover', ['label' => __('Hover', 'dynamic-content-for-madxartwork')]);
            $element->add_control('reset_button_background_hover_color', ['label' => __('Background Color', 'dynamic-content-for-madxartwork'), 'type' => Controls_Manager::COLOR, 'selectors' => ['{{WRAPPER}} .madxartwork-button.madxartwork-button-reset:hover' => 'background-color: {{VALUE}};']]);
            $element->add_control('reset_button_hover_color', ['label' => __('Text Color', 'dynamic-content-for-madxartwork'), 'type' => Controls_Manager::COLOR, 'selectors' => ['{{WRAPPER}} .madxartwork-button.madxartwork-button-reset:hover' => 'color: {{VALUE}};']]);
            $element->add_control('reset_button_hover_border_color', ['label' => __('Border Color', 'dynamic-content-for-madxartwork'), 'type' => Controls_Manager::COLOR, 'selectors' => ['{{WRAPPER}} .madxartwork-button.madxartwork-button-reset:hover' => 'border-color: {{VALUE}};'], 'condition' => ['reset_button_border_border!' => '']]);
            $element->end_controls_tab();
            $element->end_controls_tabs();
            $element->end_controls_section();
        }
    }
    public static function _add_to_form(Controls_Stack $element, $control_id, $control_data, $options = [])
    {
        if ($element->get_name() == 'form' && $control_id == 'form_fields') {
            $control_data['fields']['form_fields_enchanted_tab'] = array('type' => 'tab', 'tab' => 'enchanted', 'label' => '<i class="dynicon icon-dyn-logo-dce" aria-hidden="true"></i>', 'tabs_wrapper' => 'form_fields_tabs', 'name' => 'form_fields_enchanted_tab', 'condition' => ['field_type!' => 'step']);
            $control_data['fields']['field_type']['options']['reset'] = __('Reset', 'dynamic-content-for-madxartwork');
        }
        return $control_data;
    }
}
