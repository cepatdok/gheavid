<?php

namespace DynamicContentFormadxartwork\Extensions;

use madxartwork\Controls_Manager;
use madxartwork\Group_Control_Background;
use madxartwork\Group_Control_Typography;
use DynamicContentFormadxartwork\Helper;
if (!\defined('ABSPATH')) {
    exit;
    // Exit if accessed directly
}
class Tooltip extends \DynamicContentFormadxartwork\Extensions\DCE_Extension_Prototype
{
    public $name = 'Tooltip';
    public $has_controls = \true;
    public function get_script_depends()
    {
        return ['dce-tippy', 'dce-tooltip'];
    }
    public function get_style_depends()
    {
        return ['dce-tooltip'];
    }
    private function add_controls($element, $args)
    {
        if (\madxartwork\Plugin::$instance->editor->is_edit_mode() && !current_user_can('administrator')) {
            $element->add_control('dce_tooltip_admin_notice', ['name' => 'dce_tooltip_admin_notice', 'type' => Controls_Manager::RAW_HTML, 'raw' => __('You will need administrator capabilities to edit these settings.', 'dynamic-content-for-madxartwork'), 'content_classes' => 'madxartwork-panel-alert madxartwork-panel-alert-warning']);
            return;
        } else {
            $element->add_control('dce_enable_tooltip', ['label' => __('Tooltip', 'dynamic-content-for-madxartwork'), 'type' => Controls_Manager::SWITCHER, 'return_value' => 'yes', 'frontend_available' => \true]);
            $element->add_control('dce_tooltip_content', ['label' => __('Content', 'dynamic-content-for-madxartwork'), 'type' => Controls_Manager::TEXT, 'frontend_available' => \true, 'condition' => ['dce_enable_tooltip' => 'yes']]);
            $element->add_control('dce_tooltip_arrow', ['label' => __('Arrow', 'dynamic-content-for-madxartwork'), 'type' => Controls_Manager::SWITCHER, 'frontend_available' => 'true', 'default' => 'yes', 'condition' => ['dce_enable_tooltip' => 'yes']]);
            $element->add_control('dce_tooltip_follow_cursor', ['label' => __('Follow Cursor', 'dynamic-content-for-madxartwork'), 'type' => Controls_Manager::SELECT, 'options' => ['false' => __('No', 'dynamic-content-for-madxartwork'), 'true' => __('Yes', 'dynamic-content-for-madxartwork'), 'horizontal' => __('Horizontal', 'dynamic-content-for-madxartwork'), 'vertical' => __('Vertical', 'dynamic-content-for-madxartwork'), 'initial' => __('Initial', 'dynamic-content-for-madxartwork')], 'default' => 'false', 'frontend_available' => \true, 'condition' => ['dce_enable_tooltip' => 'yes']]);
            $element->add_responsive_control('dce_tooltip_max_width', ['label' => __('Max Width', 'dynamic-content-for-madxartwork'), 'type' => Controls_Manager::SLIDER, 'size_units' => ['px', '%'], 'label_block' => \false, 'range' => ['px' => ['min' => 80, 'max' => 800, 'step' => 10]], 'devices' => Helper::get_active_devices_list(), 'desktop_default' => ['size' => 200, 'unit' => 'px'], 'label_block' => \true, 'frontend_available' => \true, 'condition' => ['dce_enable_tooltip' => 'yes']]);
            $element->add_control('dce_tooltip_touch', ['label' => __('Touch Devices', 'dynamic-content-for-madxartwork'), 'type' => Controls_Manager::SELECT, 'options' => ['true' => __('Enable', 'dynamic-content-for-madxartwork'), 'false' => __('Disable', 'dynamic-content-for-madxartwork'), 'hold' => __('Require pressing and holding the screen to show it', 'dynamic-content-for-madxartwork')], 'default' => 'true', 'frontend_available' => \true, 'condition' => ['dce_enable_tooltip' => 'yes']]);
            $element->add_control('dce_tooltip_background_color', ['label' => __('Background Color', 'dynamic-content-for-madxartwork'), 'type' => Controls_Manager::COLOR, 'selectors' => [".tippy-box[data-theme~='theme_{{ID}}']" => 'background-color: {{VALUE}};'], 'condition' => ['dce_enable_tooltip' => 'yes']]);
            $element->add_control('dce_tooltip_color', ['label' => __('Text Color', 'dynamic-content-for-madxartwork'), 'type' => Controls_Manager::COLOR, 'selectors' => [".tippy-box[data-theme~='theme_{{ID}}']" => 'color: {{VALUE}};'], 'condition' => ['dce_enable_tooltip' => 'yes']]);
            $element->add_control('dce_tooltip_zindex', ['label' => __('Z-Index', 'dynamic-content-for-madxartwork'), 'type' => Controls_Manager::NUMBER, 'default' => '9999', 'frontend_available' => \true, 'condition' => ['dce_enable_tooltip' => 'yes']]);
        }
    }
    protected function add_actions()
    {
        add_action('madxartwork/element/common/dce_section_tooltip_advanced/before_section_end', function ($element, $args) {
            $this->add_controls($element, $args);
        }, 10, 2);
        add_action('madxartwork/widget/render_content', [$this, 'render_template'], 9, 2);
    }
    public function render_template($content, $widget)
    {
        $settings = $widget->get_settings_for_display();
        if (!empty($settings['dce_enable_tooltip'])) {
            $this->enqueue_all();
        }
        return $content;
    }
}
