<?php

namespace DynamicContentFormadxartwork\Dashboard;

use DynamicContentFormadxartwork\Notice;
class DynamicTags extends \DynamicContentFormadxartwork\Dashboard\Features
{
    public static function get_name()
    {
        return 'dynamic-tags';
    }
    public static function get_label()
    {
        return __('Dynamic Tags', 'dynamic-content-for-madxartwork');
    }
    public static function display_form()
    {
        $all_dynamic_tags = \DynamicContentFormadxartwork\Extensions::get_dynamic_tags_info();
        $non_legacy_dynamic_tags = \array_filter($all_dynamic_tags, function ($info) {
            return !(isset($info['legacy']) && $info['legacy']);
        });
        ?>
		<form action="" method="post">
		<?php 
        wp_nonce_field('dce-settings-page', 'dce-settings-page');
        if (isset($_POST['save-dce-feature'])) {
            $excluded_dynamic_tags = [];
            foreach ($all_dynamic_tags as $dynamic_tag_class => $dynamic_tag_info) {
                $excluded_dynamic_tags[$dynamic_tag_class] = !isset($_POST['dce-feature'][$dynamic_tag_class]);
            }
            // just updating would reset legacy extensions:
            $option = \json_decode(get_option('dce_excluded_dynamic_tags', '[]'), \true);
            update_option('dce_excluded_dynamic_tags', wp_json_encode($excluded_dynamic_tags + $option));
            Notice::dce_admin_notice__success(__('Your preferences have been saved.', 'dynamic-content-for-madxartwork'));
        }
        $excluded_dynamic_tags = \DynamicContentFormadxartwork\Extensions::get_excluded_dynamic_tags();
        ?>

		<div class="dce-check dce-check-all">
			<table>
				<tr>
					<td width="30">
						<input type="checkbox" name="dce-feature[]" value="true" class="dce-checkbox" id="dce-feature-all"
					<?php 
        if (!$excluded_dynamic_tags) {
            checked(\true);
        }
        ?>>
						<label for="dce-feature-all"><div id="tick_mark_small"></div></label>
					</td>
					<td>
						<?php 
        echo __('All', 'dynamic-content-for-madxartwork') . ' ' . static::get_label();
        ?>
					</td>
				</tr>
			</table>
		</div>

			<?php 
        submit_button(__('Save', 'dynamic-content-for-madxartwork') . ' ' . static::get_label());
        ?>

			<div class="dce-modules">
			<?php 
        foreach ($non_legacy_dynamic_tags as $dynamic_tag_class => $dynamic_tag_info) {
            static::show_feature($dynamic_tag_class, $dynamic_tag_info, $excluded_dynamic_tags);
        }
        ?>
			</div>
			<?php 
        submit_button(__('Save', 'dynamic-content-for-madxartwork') . ' ' . static::get_label());
        ?>

		<input type="hidden" name="save-dce-feature" value="1" />
			</form>
		<?php 
    }
}
