<?php

namespace DynamicContentFormadxartwork\Controls;

use madxartwork\Group_Control_Base;
use madxartwork\Controls_Manager;
use madxartwork\Group_Control_Background;
use DynamicContentFormadxartwork\Helper;
if (!\defined('ABSPATH')) {
    exit;
    // Exit if accessed directly.
}
class DCE_Group_Control_Ajax_Page extends Group_Control_Base
{
    protected static $fields;
    protected static $control_id;
    public static function get_type()
    {
        return 'ajax-page';
    }
    public static function get_anim_open()
    {
        $anim_p = ['none' => _x('None', 'Ajax Page', 'dynamic-content-for-madxartwork'), 'enterFromFade' => _x('Fade', 'Ajax Page', 'dynamic-content-for-madxartwork'), 'enterFromLeft' => _x('Left', 'Ajax Page', 'dynamic-content-for-madxartwork'), 'enterFromRight' => _x('Right', 'Ajax Page', 'dynamic-content-for-madxartwork'), 'enterFromTop' => _x('Top', 'Ajax Page', 'dynamic-content-for-madxartwork'), 'enterFromBottom' => _x('Bottom', 'Ajax Page', 'dynamic-content-for-madxartwork'), 'enterFormScaleBack' => _x('Zoom Back', 'Ajax Page', 'dynamic-content-for-madxartwork'), 'enterFormScaleFront' => _x('Zoom Front', 'Ajax Page', 'dynamic-content-for-madxartwork'), 'flipInLeft' => _x('Flip Left', 'Ajax Page', 'dynamic-content-for-madxartwork'), 'flipInRight' => _x('Flip Right', 'Ajax Page', 'dynamic-content-for-madxartwork'), 'flipInTop' => _x('Flip Top', 'Ajax Page', 'dynamic-content-for-madxartwork'), 'flipInBottom' => _x('Flip Bottom', 'Ajax Page', 'dynamic-content-for-madxartwork')];
        return $anim_p;
    }
    public static function get_anim_close()
    {
        $anim_p = ['none' => _x('None', 'Ajax Page', 'dynamic-content-for-madxartwork'), 'exitToFade' => _x('Fade', 'Ajax Page', 'dynamic-content-for-madxartwork'), 'exitToLeft' => _x('Left', 'Ajax Page', 'dynamic-content-for-madxartwork'), 'exitToRight' => _x('Right', 'Ajax Page', 'dynamic-content-for-madxartwork'), 'exitToTop' => _x('Top', 'Ajax Page', 'dynamic-content-for-madxartwork'), 'exitToBottom' => _x('Bottom', 'Ajax Page', 'dynamic-content-for-madxartwork'), 'exitToScaleBack' => _x('Zoom Back', 'Ajax Page', 'dynamic-content-for-madxartwork'), 'exitToScaleFront' => _x('Zoom Front', 'Ajax Page', 'dynamic-content-for-madxartwork'), 'flipOutLeft' => _x('Flip Left', 'Ajax Page', 'dynamic-content-for-madxartwork'), 'flipOutRight' => _x('Flip Right', 'Ajax Page', 'dynamic-content-for-madxartwork'), 'flipOutTop' => _x('Flip Top', 'Ajax Page', 'dynamic-content-for-madxartwork'), 'flipOutBottom' => _x('Flip Bottom', 'Ajax Page', 'dynamic-content-for-madxartwork')];
        return $anim_p;
    }
    protected function init_fields()
    {
        $fields = [];
        $fields['enabled'] = ['label' => __('Ajax Page', 'dynamic-content-for-madxartwork'), 'type' => Controls_Manager::SWITCHER, 'return_value' => 'open', 'frontend_available' => \true, 'prefix_class' => 'ajax-'];
        $fields['change_url'] = ['label' => __('Force URL update', 'dynamic-content-for-madxartwork'), 'type' => Controls_Manager::SWITCHER, 'default' => 'yes', 'return_value' => 'yes', 'frontend_available' => \true, 'condition' => ['enabled' => 'open']];
        $fields['template'] = ['label' => __('Select Template', 'dynamic-content-for-madxartwork'), 'type' => 'ooo_query', 'placeholder' => __('Template Name', 'dynamic-content-for-madxartwork'), 'label_block' => \true, 'query_type' => 'posts', 'object_type' => 'madxartwork_library', 'frontend_available' => \true, 'condition' => ['enabled' => 'open']];
        $fields['animations_heading_modal'] = ['label' => __('Animation MODAL', 'dynamic-content-for-madxartwork'), 'type' => Controls_Manager::HEADING, 'separator' => 'before', 'condition' => ['enabled' => 'open']];
        $fields['animation_open_modal'] = ['label' => _x('Enter modal from', 'Animation Control', 'dynamic-content-for-madxartwork'), 'type' => Controls_Manager::SELECT, 'default' => 'enterFromRight', 'options' => self::get_anim_open(), 'condition' => ['enabled' => 'open'], 'selectors' => ['body.modal-p-on.modal-p-{{ID}} .wrap-p .modal-p' => 'animation-name: {{VALUE}}; -webkit-animation-name: {{VALUE}};']];
        $fields['animation_close_modal'] = ['label' => _x('Close modal to', 'Animation Control', 'dynamic-content-for-madxartwork'), 'type' => Controls_Manager::SELECT, 'default' => 'exitToRight', 'options' => self::get_anim_close(), 'condition' => ['enabled' => 'open'], 'selectors' => ['body.modal-p-off.modal-p-{{ID}} .wrap-p .modal-p' => 'animation-name: {{VALUE}}; -webkit-animation-name: {{VALUE}};']];
        $fields['animations_timingFunction_heading_modal'] = ['label' => __('Timing Function', 'dynamic-content-for-madxartwork'), 'type' => Controls_Manager::HEADING, 'condition' => ['enabled' => 'open']];
        $fields['timingfunction_modal_enter'] = ['label' => _x('Enter modal', 'Animation Control', 'dynamic-content-for-madxartwork'), 'type' => Controls_Manager::SELECT, 'default' => 'ease', 'options' => Helper::get_anim_timing_functions(), 'selectors' => ['body.modal-p-on.modal-p-{{ID}} .wrap-p .modal-p' => 'animation-timing-function: {{VALUE}}; -webkit-animation-timing-function: {{VALUE}};'], 'condition' => ['enabled' => 'open']];
        $fields['timingfunction_modal_close'] = ['label' => _x('Close modal', 'Animation Control', 'dynamic-content-for-madxartwork'), 'type' => Controls_Manager::SELECT, 'default' => 'ease', 'options' => Helper::get_anim_timing_functions(), 'selectors' => ['body.modal-p-off.modal-p-{{ID}} .wrap-p .modal-p' => 'animation-timing-function: {{VALUE}}; -webkit-animation-timing-function: {{VALUE}};'], 'condition' => ['enabled' => 'open']];
        $fields['animations_time_heading_modal'] = ['label' => __('Time', 'dynamic-content-for-madxartwork'), 'type' => Controls_Manager::HEADING, 'condition' => ['enabled' => 'open']];
        $fields['duration_modal'] = ['label' => _x('Duration', 'Animation Control', 'dynamic-content-for-madxartwork'), 'type' => Controls_Manager::SLIDER, 'default' => ['unit' => 's', 'size' => 0.7], 'range' => ['s' => ['min' => 0, 'max' => 10, 'step' => 0.1]], 'size_units' => ['s'], 'selectors' => ['body.modal-p-{{ID}} .wrap-p .modal-p' => 'animation-duration: {{SIZE}}{{UNIT}}; -webkit-animation-duration: {{SIZE}}{{UNIT}};'], 'condition' => ['enabled' => 'open']];
        $fields['delay_modal'] = ['label' => _x('Enter delay', 'Animation Control', 'dynamic-content-for-madxartwork'), 'type' => Controls_Manager::SLIDER, 'default' => ['unit' => 's', 'size' => 0], 'range' => ['s' => ['min' => 0, 'max' => 10, 'step' => 0.1]], 'size_units' => ['s'], 'selectors' => ['body.modal-p-on.modal-p-{{ID}} .wrap-p .modal-p' => 'animation-delay: {{SIZE}}{{UNIT}}; -webkit-animation-delay: {{SIZE}}{{UNIT}};'], 'condition' => ['enabled' => 'open'], 'separator' => 'after'];
        $fields['animations_heading_body'] = ['label' => __('Animation BODY', 'dynamic-content-for-madxartwork'), 'type' => Controls_Manager::HEADING, 'separator' => 'before', 'condition' => ['enabled' => 'open']];
        $fields['animation_close_body'] = ['label' => _x('Exit body to', 'Animation Control', 'dynamic-content-for-madxartwork'), 'type' => Controls_Manager::SELECT, 'default' => 'exitToLeft', 'options' => self::get_anim_close(), 'condition' => ['enabled' => 'open'], 'selectors' => ['body.modal-p-on.modal-p-{{ID}} #dce-wrap' => 'animation-name: {{VALUE}}; -webkit-animation-name: {{VALUE}};']];
        $fields['animation_open_body'] = ['label' => _x('Return body from', 'Animation Control', 'dynamic-content-for-madxartwork'), 'type' => Controls_Manager::SELECT, 'default' => 'enterFromLeft', 'options' => self::get_anim_open(), 'condition' => ['enabled' => 'open'], 'selectors' => ['body.modal-p-off.modal-p-{{ID}} #dce-wrap' => 'animation-name: {{VALUE}}; -webkit-animation-name: {{VALUE}};']];
        $fields['animations_timingFunction_heading_body'] = ['label' => __('Timing Function', 'dynamic-content-for-madxartwork'), 'type' => Controls_Manager::HEADING, 'condition' => ['enabled' => 'open']];
        $fields['timingfunction_exit_body'] = ['label' => _x('Exit', 'Animation Control', 'dynamic-content-for-madxartwork'), 'type' => Controls_Manager::SELECT, 'default' => 'ease', 'options' => Helper::get_anim_timing_functions(), 'selectors' => ['body.modal-p-on.modal-p-{{ID}} #dce-wrap' => 'animation-timing-function: {{VALUE}}; -webkit-animation-timing-function: {{VALUE}};'], 'condition' => ['enabled' => 'open']];
        $fields['timingfunction_return_body'] = ['label' => _x('Return', 'Animation Control', 'dynamic-content-for-madxartwork'), 'type' => Controls_Manager::SELECT, 'default' => 'ease', 'options' => Helper::get_anim_timing_functions(), 'selectors' => ['body.modal-p-off.modal-p-{{ID}} #dce-wrap' => 'animation-timing-function: {{VALUE}}; -webkit-animation-timing-function: {{VALUE}};'], 'condition' => ['enabled' => 'open']];
        $fields['animations_time_heading_body'] = ['label' => __('Time', 'dynamic-content-for-madxartwork'), 'type' => Controls_Manager::HEADING, 'condition' => ['enabled' => 'open']];
        $fields['duration_body'] = ['label' => _x('Duration', 'Animation Control', 'dynamic-content-for-madxartwork'), 'type' => Controls_Manager::SLIDER, 'default' => ['unit' => 's', 'size' => 0.7], 'range' => ['s' => ['min' => 0, 'max' => 10, 'step' => 0.1]], 'size_units' => ['s'], 'selectors' => ['body.modal-p-{{ID}} #dce-wrap' => 'animation-duration: {{SIZE}}{{UNIT}}; -webkit-animation-duration: {{SIZE}}{{UNIT}};'], 'condition' => ['enabled' => 'open']];
        $fields['delay_body'] = ['label' => _x('Return delay', 'Animation Control', 'dynamic-content-for-madxartwork'), 'type' => Controls_Manager::SLIDER, 'default' => ['unit' => 's', 'size' => 0], 'range' => ['s' => ['min' => 0, 'max' => 10, 'step' => 0.1]], 'size_units' => ['s'], 'selectors' => ['body.modal-p-off.modal-p-{{ID}} #dce-wrap' => 'animation-delay: {{SIZE}}{{UNIT}}; -webkit-animation-delay: {{SIZE}}{{UNIT}};'], 'condition' => ['enabled' => 'open']];
        $fields['bg_modal'] = ['label' => __('Background Color', 'dynamic-content-for-madxartwork'), 'type' => Controls_Manager::COLOR, 'selectors' => ['body.modal-p-on.modal-p-{{ID}} .wrap-p .modal-p' => 'background-color: {{VALUE}};'], 'default' => '#FFF', 'separator' => 'before', 'condition' => ['enabled' => 'open']];
        return $fields;
    }
    protected function add_group_args_to_field($control_id, $field_args)
    {
        self::$control_id = $control_id;
        $field_args = parent::add_group_args_to_field($control_id, $field_args);
        return $field_args;
    }
    protected function get_default_options()
    {
        return ['popover' => \false];
    }
}
