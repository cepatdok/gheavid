<?php

namespace DynamicContentFormadxartwork\Modules\DynamicTags\Tags;

use madxartwork\Core\DynamicTags\Tag;
use madxartwork\Controls_Manager;
if (!\defined('ABSPATH')) {
    exit;
    // Exit if accessed directly
}
class DCE_DynamicTag_Template extends Tag
{
    public function get_name()
    {
        return 'dce-template';
    }
    public function get_title()
    {
        return __('Template', 'dynamic-content-for-madxartwork');
    }
    public function get_group()
    {
        return 'dce';
    }
    public function get_categories()
    {
        return [
            'base',
            //\madxartwork\Modules\DynamicTags\Module::BASE_GROUP
            'text',
        ];
    }
    public function get_docs()
    {
        return 'https://www.dynamic.ooo/widget/dynamic-tag-template/';
    }
    /**
     * Register Controls
     *
     * Registers the Dynamic tag controls
     *
     * @since 2.0.0
     * @access protected
     *
     * @return void
     */
    protected function _register_controls()
    {
        $this->add_control('dce_template', ['label' => __('Template', 'dynamic-content-for-madxartwork'), 'type' => 'ooo_query', 'placeholder' => __('Template Name', 'dynamic-content-for-madxartwork'), 'label_block' => \true, 'query_type' => 'posts', 'object_type' => 'madxartwork_library']);
        $this->add_control('dce_template_new', ['type' => Controls_Manager::RAW_HTML, 'raw' => '<a class="madxartwork-button madxartwork-button-block madxartwork-field-textual madxartwork-size-sm madxartwork-button-success" href="' . admin_url('edit.php?post_type=madxartwork_library#add_new') . '" target="_blank"><i class="eicon-plus"></i> ' . __('Add new template', 'dynamic-content-for-madxartwork') . '</a>', 'condition' => ['dce_template' => '']]);
        $this->add_control('dce_template_post_id', ['label' => __('Post', 'dynamic-content-for-madxartwork'), 'type' => 'ooo_query', 'placeholder' => __('Force Post content', 'dynamic-content-for-madxartwork'), 'label_block' => \true, 'query_type' => 'posts', 'condition' => ['dce_template!' => '']]);
        $this->add_control('dce_template_user_id', ['label' => __('User', 'dynamic-content-for-madxartwork'), 'type' => 'ooo_query', 'placeholder' => __('Force User content', 'dynamic-content-for-madxartwork'), 'label_block' => \true, 'query_type' => 'users', 'condition' => ['dce_template!' => '']]);
        $this->add_control('dce_template_author_id', ['label' => __('Author', 'dynamic-content-for-madxartwork'), 'type' => 'ooo_query', 'placeholder' => __('Force Author content', 'dynamic-content-for-madxartwork'), 'label_block' => \true, 'query_type' => 'users', 'condition' => ['dce_template!' => '']]);
        $this->add_control('dce_template_inline_css', ['label' => __('Inline CSS', 'dynamic-content-for-madxartwork'), 'type' => \madxartwork\Controls_Manager::SWITCHER, 'condition' => ['dce_template!' => '']]);
        $this->add_control('dce_template_code', ['label' => __('Show shortcode', 'dynamic-content-for-madxartwork'), 'type' => \madxartwork\Controls_Manager::SWITCHER, 'condition' => ['dce_template!' => '']]);
        $this->add_control('dce_template_help', ['type' => \madxartwork\Controls_Manager::RAW_HTML, 'raw' => '<div id="madxartwork-panel__editor__help" class="p-0"><a id="madxartwork-panel__editor__help__link" href="' . $this->get_docs() . '" target="_blank">' . __('Need Help', 'dynamic-content-for-madxartwork') . ' <i class="eicon-help-o"></i></a></div>', 'separator' => 'before']);
    }
    public function render()
    {
        $settings = $this->get_settings_for_display(null, \true);
        if (empty($settings)) {
            return;
        }
        if (!empty($settings['dce_template'])) {
            $template = '[dce-madxartwork-template id="' . $settings['dce_template'] . '"';
            if ($settings['dce_template_post_id']) {
                $template .= ' post_id="' . $settings['dce_template_post_id'] . '"';
            }
            if ($settings['dce_template_user_id']) {
                $template .= ' user_id="' . $settings['dce_template_user_id'] . '"';
            }
            if ($settings['dce_template_author_id']) {
                $template .= ' author_id="' . $settings['dce_template_author_id'] . '"';
            }
            if ($settings['dce_template_inline_css']) {
                $template .= ' inlinecss="true"';
            }
            $template .= ']';
            if ($settings['dce_template_code']) {
                echo $template;
                return;
            }
            $template = \DynamicContentFormadxartwork\Helper::get_dynamic_value($template);
            echo $template;
        }
    }
}
